# Starter Prompt — Phase 2C

Put `02C_SCALE_AUDIT_AND_ANSWERS.md` alongside the other spec files, then paste the block below into
Copilot. **One phase per session.**

---

> Read `docs/spec/00_MASTER_SPEC.md` in full — it is **version 2** and supersedes the master spec you
> may have read in earlier sessions; its §0 lists exactly what changed and three of those changes
> reverse earlier instructions. Then read `docs/spec/02C_SCALE_AUDIT_AND_ANSWERS.md`.
> Phase 2 items 2.1, 2.2, 2.3, 2.5 and 2.6 are complete and reviewed. Item 2.4 is blocked and Item
> 2.7 has not started — this round does not unblock them. Execute Phase 2C exactly as written.
>
> **This is not a fix round.** It is safety, instrumentation and audit. Four things will make it
> succeed or fail:
>
> **One — Part A comes first and nothing else runs until it verifies.** Last round a command's
> timeout expired but its child kept running and held 5,553.39 MB until it was killed by hand.
> `subprocess.run(timeout=...)` will not fix this: the direct child is `uv`, and killing it leaves
> `python.exe` holding the memory. Kill the whole process tree.
>
> **Two — the B1 row ceiling must RAISE.** Not truncate, not sample, not warn and continue, and
> absolutely not `LIMIT`. The application becoming loudly unable to fetch 3.1M rows is the intended
> outcome. Master spec §7 — expect loud failures, do not suppress them. Create `ROW_CEILING_EXEMPT`
> empty and add nothing to it; if you think an entry is needed, stop and report.
>
> **Three — Part C changes nothing.** It is an inventory. Every call site in `app/` that pulls rows
> into Python, with its filters, its grain, and whether it is bounded. Where a call passes `{}` as
> params, write `{} — UNFILTERED` rather than leaving it blank. Where you cannot get a real row count
> from TigerGraph, write `UNKNOWN` and say what you tried. Do not estimate.
>
> **Four — no GSQL.** Not authored, not edited, not installed, not dropped, not drafted. The audit is
> what the operator reviews before authorizing GSQL in the next round. If an item seems to require
> new GSQL, that is the expected finding — report it and stop.
>
> Do not re-run `compute_firm_exceptions` or the full-book rule verification until Item A1 verifies.
> Those commands orphaned a 5.5 GB process last round.
>
> Follow the verify-before-change protocol in master spec §4 for every item: CHECK, COMPARE, then
> either record "already correct" or apply the change, then VERIFY. Paste exact command output
> throughout — never paraphrase it, and never summarize output in place of showing it.
>
> Part D is twelve specific questions from the review of your last report. Answer each in Section 4
> with exact output, or state plainly that you could not determine it. An honest "undetermined, here
> is what I tried" is a correct answer; an inferred one is not. D8 in particular — run the seven V0
> seed rules through `validate_plan` and report which raise, but **do not fix any that fail.**
>
> Write your completion report to `docs/analysis/PHASE_2C_COMPLETE.md` in the master spec §9 format,
> plus the extra Section 8 the phase file specifies for the materialization inventory. Do not
> summarize that table — it is what the next round is built from.
>
> In Section 5, paste the exact command and verbatim output showing April firm-basis revenue is still
> $397,389,374.54. Prose is not sufficient for this figure.
>
> Leave the backend running on 127.0.0.1:8002 and the frontend on 127.0.0.1:3002, and confirm both
> respond. Do not proceed to Phase 3.
