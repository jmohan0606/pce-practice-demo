# PCE Practice Demo — Master Spec for Fix Rounds

**Version 2 — supersedes the version dated at Phase 1.** Read this file first, every session, before
any phase file. The phase file tells you *what* to do; this file tells you *how* and what you must
never do. Where the two disagree, **this file wins** — report the conflict.

---

## 0 · What changed in version 2, and why

Version 1 was written before Phases 1 and 2 ran. Four of its statements are now false and one of them
would block correct work. Read this section; do not rely on remembered content from version 1.

| § | Version 1 said | Reality now |
|---|---|---|
| 2 | Catalog has 46 entries, `lookups.py` does not exist, Round 9 absent | Catalog is **61**, `lookups.py` exists, contract checker passes 5/5 |
| 2 | "**No GSQL authoring work is required in any phase**" | **False.** New GSQL is required. See §2. |
| 2 | If a phase seems to need new GSQL, an installed query is probably just uncatalogued | **No longer available.** The catalog is fully reconciled — that escape hatch is closed. |
| 6 | 60-second command limit | Unenforceable and routinely breached. Replaced by §7 with real limits and process-tree kill. |
| 3 | Seven invariants | **Ten.** Three added after Phase 2 findings. |

---

## 1 · What this application is

A demo for a wealth-management client. It reads compensation plan documents, extracts rules from them
with an LLM, evaluates those rules against a TigerGraph graph of revenue data, and generates
narrative insights.

**The governing principle:**

> **TigerGraph computes the numbers. Python interprets and narrates. The AI never computes a figure.**

Every number on screen traces to a query result or a document citation.

**The operational restatement of that principle, which Phase 2 proved was being violated:**

> **Move the question to the data. Never move the data to the question.**

If Python is looping over rows to decide something, the decision belongs in the query.

---

## 2 · State of the system

**Data is loaded and reconciles.** TigerGraph holds 40,047,519 vertex rows and 104,273,975 edge rows.
April firm-basis revenue is **$397,389,374.54** against the client's own PCE report of
$403,533,981.62 — the $7.6M gap is advisors outside the cohort, verified.

| | |
|---|---|
| Scope | April–June 2026, dated by **`proc_dt`** |
| Cohort | **5,455 advisors** by the client's definition |
| Transactions | **12,360,142** |
| NULL-advisor rows | 4,136,967 under a synthetic `__UNATTRIBUTED__` — counted firm-wide, excluded from advisor views |
| Firm reason filter | excludes `9X`, `XX` |
| Advisor reason filter | also excludes `9R`, `98`, `99`, `9H` |

**The firm total does not equal the sum of advisors, and that is correct.**

**The catalog is reconciled.** 60 queries installed, 61 catalogued. Every installed query is
catalogued. The one catalog-only entry is `rules_evaluate_plan`, correct by design (invariant 7).

**GSQL authoring is now required — and is authorized only by explicit written operator instruction
in a phase file.** Version 1 said no GSQL work was needed anywhere, on the reasoning that any
apparent gap meant an installed query was simply uncatalogued. Item 2.2 closed that possibility: the
catalog and the install list now match completely. Where the application needs an aggregate that no
installed query provides, **that is a genuine gap, not a registration error.**

Consequently:

- **Do not author GSQL on your own judgement, in any phase, ever.**
- **Do not conclude that a needed query must already exist.** It may not.
- When a phase file explicitly authorizes named GSQL work, do exactly that and nothing adjacent.
- Otherwise: report the gap, name the aggregate required, and stop.

**The known scale defect, measured.** The application currently pulls whole-month populations into
Python. `_advisor_accounts` in `app/insights/exceptions.py` fetches 3,123,924 rows for one month and
groups them by advisor in a Python loop; the process reached **5,553.39 MB**. This is a violation of
invariant 2 and it is the reason Phase 2 items 2.4 and 2.7 are blocked.

**Phase 1 fixed one memory source, not the class.** It stopped `FoundationGraphStore` loading CSVs in
real mode. It did not and cannot stop a TigerGraph query returning millions of rows into Python. The
Phase 1 figure of `83.89 MB` was measured on a path that *refuses*; it never described a path that
works.

**A completed demo was run from this environment.** Some files here contain fixes that exist nowhere
else. **This environment is the source of truth, not any reference tree.**

---

## 3 · Hard invariants — never violate these

1. **No mock data in real mode, ever.** The local CSV store (`FoundationGraphStore`) must never serve
   a read when `graph_client_mode` is not `mock` or `local`.

2. **No whole-table loads into Python.** Filtering, aggregation and projection happen in TigerGraph.
   Python receives small filtered results. **A query result larger than `MAX_QUERY_ROWS` (default
   50,000) must raise, not truncate.** Column projection alone does not satisfy this invariant — a
   result narrowed to three columns and 3.1 million rows is still a whole-table load.

3. **Refuse, never silently degrade.** A crash is better than a wrong number. A loud refusal naming
   the query is better than both. **No `LIMIT` without a deterministic `ORDER BY`, no sampling, no
   approximate aggregates, no truncation-with-a-warning.** A cap that *raises* is fine.

4. **No partial results, ever.** A figure is complete and correct, or it is absent with an error
   attached. Never render a number computed from part of a population. If a computation cannot finish,
   the surface shows the failure — it does not show what was gathered so far. This includes:
   ranks assigned over an incomplete set, sums that stopped early, percentages whose denominator was
   not fully counted, and any list whose ordering depends on iteration order rather than an explicit
   deterministic sort with a defined tie-break.

5. **Never change what a query returns to make something work.** Do not touch reason-code filters,
   `__UNATTRIBUTED__` handling, `proc_dt` attribution, or cohort definition. If a fix would alter a
   client-facing figure, **stop and report before making it**.

6. **Aggregation belongs in TigerGraph; interpretation belongs in Python.** A `GROUP BY`, a `SUM`, a
   `COUNT`, a join, or a filter written as a Python loop over query results is a defect regardless of
   how small the current data happens to be. Deciding *what a result means* — thresholds, exclusions,
   wording, ranking policy — is Python's job.

7. **`rules_evaluate_plan` is Python, by design.** It is the plan interpreter — it takes a compiled
   plan (filters, aggregate, trigger, grain) and evaluates it. GSQL cannot accept an arbitrary plan
   structure as a parameter. **Never attempt to install it as a GSQL query.** Its *row reads* go to
   the installed `rule_evaluation_rows`. Invariant 6 does not override this: the interpreter stays in
   Python, but the filters and aggregate it needs must be pushed into the row query rather than
   applied by looping.

8. **One figure, one source.** A client-facing number is computed in exactly one place. If the same
   figure is produced by two code paths, that is a defect even when the two agree — and Phase 2 found
   a case where they disagreed in the last digits. Name the authoritative path; delete or delegate
   the other.

9. **Content over timestamps.** File modification times reflect when files were copied, not what is
   in them. A file labelled "newer" has been observed running older code. Judge by markers and content
   only.

10. **Approved/published rules are never silently deleted.** They may be superseded or deactivated.

---

## 4 · The verify-before-change protocol

**For every change in every phase:**

1. **CHECK** — run the stated check command. Record the exact output.
2. **COMPARE** — does current state already match the target?
   - **Matches** → record "already correct", change nothing, move on.
   - **Does not match, and the phase file states the fix** → apply the fix.
   - **Does not match, and the phase file states only a goal** → diagnose, then fix (see §6).
3. **VERIFY** — re-run the check. Record the exact output. If it still does not match, **stop and
   report**. Do not attempt a second, different fix without reporting the first failure.

**Never change a file you have not first checked.** Never assume a previous phase left something in a
particular state — re-check it.

---

## 5 · What a check must assert

Phase 2 passed several checks cleanly while the code under them was badly broken. The checks were not
wrong; they asked the wrong question. `app/insights/exceptions.py` satisfies the `findstr` check and
the STRICT `check_store_reads.py` guard, and pulls 3,123,924 rows.

**Before accepting any check as evidence, state what it does not cover.**

| A check that asserts | Does **not** tell you |
|---|---|
| No local-store reads | How many rows came back |
| A projection is present | Whether it narrowed rows or only columns |
| A query name is catalogued | Whether the installed body matches the local source |
| A function returns the right shape | Whether it finished, or how much memory it used |
| It passed at mock scale | Anything whatsoever about real scale |

**A claim proven at 2,190 rows is a claim about 2,190 rows.** Before accepting that something works,
state what its number becomes at 12.4 million. If you cannot state it, the item is undiagnosed.

**Every verification of a data path must report three things:** the row count, the elapsed time, and
the peak working set. A verification missing any of the three is incomplete — say so rather than
recording a pass.

---

## 6 · When the cause is unknown

Some phase items state a **goal and an acceptance test** but not a fix, because nobody has diagnosed
them yet. For these:

1. Diagnose first. Trace the code path. Read the actual response. Report what you find.
2. **If you find the cause, fix it**, and state the cause in the completion report.
3. **If you cannot determine the cause, STOP AND REPORT.** Do not guess. Do not implement a
   plausible-looking fix for an undiagnosed problem. Write what you tried, what you observed, and
   what you would need in order to proceed.

A phase that reports "three fixed, two undiagnosed with evidence attached" is a **success**. A phase
that reports "five fixed" where two were guesses is a failure that will cost more later.

**Stopping has been correct every time it has happened on this project.** Treat it as the expected
outcome of an honest round, not as a delay.

---

## 7 · Operating rules

- **Report exact commands and exact output.** Paste output verbatim, including errors. Never
  paraphrase output in place of showing it, and never write "recorded above" in place of showing it —
  each report must stand alone.

- **Every command that touches real data runs through `scripts/run_bounded.py`.** It enforces a
  timeout and **kills the entire process tree** on expiry, then reports elapsed seconds and peak
  working set.

  A plain `subprocess.run(timeout=...)` is not sufficient. With `uv run python -c ...` the direct
  child is `uv`; killing it leaves `python.exe` running. **This has already happened** — an orphaned
  process held 5,553.39 MB past a 300-second timeout and was found only because the operator noticed
  system memory at 98%.

- **Time limits.** Default 120 seconds. A phase item may state a longer limit explicitly. When a
  command hits its limit, record the limit, the elapsed time, and confirm the tree was killed.
  **A command that hits its limit is a finding, not a retry prompt** — do not re-run it with a longer
  timeout unless a phase file says to.

- **Report memory for every data-path command**, whether or not it completed. The working set at the
  moment of cancellation is itself evidence. "It did not finish so I did not measure it" is not
  acceptable — the measurement is most valuable precisely when the command fails.

- **If something cannot be measured, say so.** Do not substitute a different measurement.

- **A zero is a finding.** A count of 0, an empty result, a missing table, an unchanged file —
  investigate it and say what it means.

- **One change at a time**, verified, before the next.

- **Take a full workspace copy before each phase.** There is no git in this environment —
  `fatal: not a git repository`. A folder copy is the only rollback that exists.

---

## 8 · Keep the application running

After each phase, leave both services running so the operator can test:

```bat
:: backend
uv run uvicorn app.api.main:app --host 127.0.0.1 --port 8002 --reload

:: frontend
cd frontend && npm run dev
```

Report the URLs and confirm both respond. **Report the backend process's own working set** — an idle
backend carrying gigabytes is a resident leak and a finding. Confirm no listener exists on any port
other than 8002 and 3002; a duplicate backend on port 8000 has been found once already.

If a phase leaves the app unable to start, **say so prominently at the top of the completion report**
and state exactly why.

**Expect loud failures.** Endpoints that read local CSVs, and now endpoints that request oversized
results, will raise. That is the correct and intended state. **Do not suppress those errors to keep
the app quiet, and do not add an exemption to make one go away.**

---

## 9 · Completion report format

At the end of each phase, write `docs/analysis/PHASE_<n>_COMPLETE.md` with **exactly these sections**:

```markdown
# Phase <n> Complete — <title>

## 1. Status
One block. What was fixed, what was already correct, what is undiagnosed, what is blocked.
No recommendations here.

## 2. Items
One subsection per numbered item in the phase file. Each with:
  - **Check command and exact output** (before) — pasted, never referenced
  - **State found**: already correct / fixed / undiagnosed / blocked
  - **What was changed** — exact files and what changed in each. "None" if nothing.
  - **Verify command and exact output** (after)
  - **Cost** — rows returned, elapsed seconds, peak working set, for any data-path item

## 3. Files changed
Complete list, one per line, full relative path. This is how the operator reviews the diff.
Every file you edited appears here, including helper and script files.

## 4. What I could not do
Every item that failed, timed out, or could not be diagnosed. What you tried, what it returned,
and what you would need to proceed. Be specific.

## 5. Numbers check
Confirm no client-facing figure changed. If any did, state which and why.
Where the phase touches revenue, paste the **command and verbatim output** showing April
firm-basis is still $397,389,374.54. Prose restatement is not sufficient for this figure.

## 6. App state
Backend URL, frontend URL, both confirmed responding, backend working set.
Any endpoint now raising, and why. Any listener on an unexpected port.

## 7. Ready for next phase
Yes / No. If no, what blocks it.
```

Where a phase file specifies additional sections, append them after Section 7.

---

## 10 · Phase index

| Phase | File | Goal | State |
|---|---|---|---|
| 1 | `01_PHASE_1_LOCAL_STORE_GUARD.md` | Stop the memory crash; end mock data in real mode | Complete |
| 2 | `02_PHASE_2_CATALOG_AND_RULES.md` | Catalog reconciled; rules evaluate; citations return | 2.1/2.2/2.3/2.5/2.6 done; 2.4 and 2.7 blocked on scale |
| 2C | `02C_SCALE_AUDIT_AND_ANSWERS.md` | Safety, row ceiling, full materialization audit | Next |
| 2D | `02D_PUSHDOWN_REMEDY.md` | Fix the scale defect. **Written after 2C's audit, authorizing named GSQL.** | Not yet written |
| 3 | `03_PHASE_3_DELETE_AND_RESET.md` | Delete controls with cascade; clean slate | Blocked — see below |
| 4 | `04_PHASE_4_DOCUMENTS_AND_RULES_UI.md` | Documents & Rules page rebuilt to mockup | Partly blocked |
| 5 | `05_PHASE_5_OPPORTUNITIES_AND_COACHING.md` | Opportunities and Coaching populated | Largely independent |

**Run them in order.** Do not start a phase until the operator has reviewed the previous completion
report and said to proceed.

**Phase 3 carries a trap.** `ensure_v0_seed()` no-ops whenever any rule-set version exists. Clear the
rule store and it runs at startup — and it calls `validate_plan`, which **executes plans against
data**. If the rules path is broken, startup raises and the app will not come up, with no git to roll
back. **The rules path must work before anything is wiped.**

---

## 11 · The mockups are the UI spec

They are in the repository at `docs/ui/`:

| File | Covers |
|---|---|
| `MOCKUP_ROUND_A_DASHBOARD.html` | Dashboard, drivers, exceptions, non-credited, citations |
| `MOCKUP_RULE_LIST_MANAGEMENT.html` | Documents & Rules — rule list, grouping, filters, delete |
| `MOCKUP_RULE_AUTHORING.html` | Write a Rule, Generate Query, Preview, Retry, document upload |
| `MOCKUP_RULE_VERSIONS.html` | Version history |
| `MOCKUP_DRILLDOWN.html` | Evidence drill-down tables |
| `MOCKUP_CHAT.html` | Chat |
| `MOCKUP_FEATURE_FLAGS.html` | Feature flags |

**Where a phase file references a mockup, open it and match it.** The mockups are contract specs —
they state API shapes and behavioural rules, not just layout. The current UI has drifted from them
over recent rounds; the mockup is correct and the current UI is not.
