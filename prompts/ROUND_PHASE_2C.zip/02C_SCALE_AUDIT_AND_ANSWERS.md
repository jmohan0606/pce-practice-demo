# Phase 2C — Scale Safety, Instrumentation, and Audit

**Read `00_MASTER_SPEC.md` (version 2) in full first.** Version 2 supersedes the earlier master
spec — its §0 lists what changed. Do not rely on remembered content from version 1.

Phase 2 items 2.1, 2.2, 2.3, 2.5 and 2.6 are complete and
reviewed. Item 2.4 is blocked at live verification and Item 2.7 has not started. This file does not
unblock them — it produces the evidence the operator needs in order to authorize the remedy.

---

## Why this round exists

Phase 2 established that Phase 1 fixed **one** memory source and not the class. Phase 1 stopped
`FoundationGraphStore` loading CSVs in real mode. It did not and could not stop a TigerGraph query
returning millions of rows into Python. The measured evidence:

| | |
|---|---|
| Pre-Phase-1, local CSV path | 6,718.76 MB, still growing at 59.6s |
| Post-Phase-1, path that **refuses** | 83.89 MB in 1.2s |
| Post-Phase-1, real TigerGraph path that **succeeds** | **5,553.39 MB**, orphaned past 300s |

The `83.89 MB` figure only ever described a path that refuses. Any path that reaches TigerGraph and
returns is still free to materialize whatever comes back.

**The root reason this was not caught earlier:** every guard built so far asks *"does this read the
local store?"* No guard asks *"how many rows came back?"* `app/insights/exceptions.py` passes the
`findstr` check and the STRICT `check_store_reads.py` guard cleanly, and still pulls 3,123,924 rows.

This round installs the missing question, then answers it everywhere at once.

---

## What this round does NOT do

Read this list twice. Doing any of it is a failure of the round, not an overachievement.

- **No GSQL is authored, edited, installed, or dropped.** Not one line. The audit output is what the
  operator uses to authorize GSQL work in a later round.
- **`_advisor_accounts`, `compute_firm_exceptions`, and the rule population path are NOT fixed here.**
  They are measured and reported.
- **No `LIMIT` is added anywhere.** No sampling, no truncation, no "cap it and warn". Master spec
  invariant 3. A cap that *raises* is the only acceptable cap.
- **Item 2.4 and Item 2.7 remain blocked.** Do not attempt them.
- **Do not re-run `compute_firm_exceptions` or the full-book rule verification** until Item A1 is
  complete and verified. Those commands orphaned a 5.5 GB process last round.

If an item below seems to require something on this list, **stop and report**.

---

# Part A — Safety. Nothing else runs until this is done.

## Item A1 — Process-tree cancellation on timeout

**Problem, measured.** Last round the foreground tool timeout expired at 300 seconds and returned,
but the child process kept running and held 5,553.39 MB until it was killed by hand. It was found
only because the operator noticed system memory at 98%.

```
PID          : 32720
WorkingSetMB : 5553.39
CommandLine  : python.exe -u -c "from app.insights.exceptions import compute_firm_exceptions as f; ..."
```

**Goal.** Any command you launch that exceeds its timeout has its **entire process tree** terminated
— the `uv` parent, the Python launcher, and the worker — before you move on.

**How.** Create `scripts/run_bounded.py`: launches a command, enforces a timeout, and on expiry kills
the whole tree, then reports elapsed seconds and peak working set observed.

**Do NOT do the naive version.** `subprocess.run(..., timeout=N)` kills only the direct child. The
`uv run python -c ...` chain means the direct child is `uv`; killing it leaves `python.exe` holding
the memory. That is exactly what happened. Use a job object / process group and kill the tree.

**CHECK**

```bat
:: prove the defect still exists before fixing it
uv run python -c "import subprocess,sys; subprocess.run([sys.executable,'-c','import time;time.sleep(120)'],timeout=5)"
:: then, in another shell:
powershell "Get-Process python | Select-Object Id,WorkingSet64,StartTime"
```

Record whether a `python` process survives the timeout.

**VERIFY**

```bat
uv run python scripts/run_bounded.py --timeout 5 -- uv run python -c "import time; time.sleep(120)"
powershell "Get-Process python -ErrorAction SilentlyContinue | Select-Object Id,StartTime"
```

Acceptance: the second command shows **no surviving process** from that launch, and `run_bounded.py`
printed elapsed seconds and the peak working set it observed.

**From this item onward, every long-running command in this round goes through `run_bounded.py`.**
State in the report which commands you ran through it.

## Item A2 — Orphan sweep and port hygiene

**CHECK**

```bat
powershell "Get-CimInstance Win32_Process | Where-Object {$_.CommandLine -match 'uvicorn|app\.insights|app\.rules'} | Select-Object ProcessId,WorkingSetSize,CommandLine | Format-List"
powershell "Get-NetTCPConnection -State Listen | Where-Object {$_.LocalPort -in 3000,3002,8000,8002} | Select-Object LocalAddress,LocalPort,OwningProcess"
powershell "$os=Get-CimInstance Win32_OperatingSystem; [PSCustomObject]@{TotalGB=[math]::Round($os.TotalVisibleMemorySize/1MB,2);FreeGB=[math]::Round($os.FreePhysicalMemory/1MB,2)}"
```

**Report.** Every listener found, its owning PID, and its working set. Last round an **unused
duplicate backend on port 8000** was found and stopped — report where it came from if you can
determine it, and whether anything was configured to point at it.

**Also report the working set of the backend on 8002 specifically.** Post-cleanup the machine showed
38.5% of 32 GB in use with only backend and frontend running. State how much of that is the backend
process. If it is carrying multiple GB while idle, that is a resident leak and a finding.

---

# Part B — Instrumentation. The missing question, installed once, centrally.

## Item B1 — Row-count ceiling that RAISES

**Goal.** No catalog query result larger than a configured ceiling ever reaches application code.

**Where.** `app/graph/queries/catalog.py`, inside `run_catalog_query`, at the single point where the
result rows are returned — after any existing normalization, before the return.

**Behaviour.**

- Ceiling read from env `MAX_QUERY_ROWS`, default **50000**.
- If `len(rows) > ceiling`, **raise**. Do not truncate. Do not log-and-continue.
- The exception message must name: the query name, the actual row count, the ceiling, and the exact
  params dict that produced it.

**Worked example of the required message:**

```
QueryResultTooLarge: rule_evaluation_rows returned 3123924 rows (ceiling 50000).
params={'vertex_type': 'phx_dm_pce_account_month', 'month': '202605', 'columns': 'acct_key,advisor_sid,credited_amt'}
This violates master spec invariant 2 — filtering and aggregation belong in TigerGraph.
```

**Do NOT do the naive version.** Do not add `LIMIT` to the query to keep the count under the ceiling.
Do not slice the list. Do not add an allowlist of "known big" queries so the app stays quiet. The
point of this item is that the app becomes loudly unable to do the wrong thing. Master spec §8:
expect loud failures, do not suppress them.

**One permitted exemption mechanism, and only one.** If a query legitimately must return more than
the ceiling, it is exempted by an explicit named entry in a constant `ROW_CEILING_EXEMPT` with a
one-line written justification per entry. **Add no entries in this round.** Create the constant
empty. If you believe an entry is needed, stop and report which and why.

**CHECK** — record current behaviour: no ceiling exists, so state that.

**VERIFY**

```bat
uv run python scripts/run_bounded.py --timeout 300 -- uv run python -u -c "from app.graph.queries.lookups import fetch_vertex_rows; r=fetch_vertex_rows('phx_dm_pce_account_month', month='202605', columns='acct_key,advisor_sid,credited_amt'); print(len(r))"
```

Acceptance: this **raises** `QueryResultTooLarge` naming 3,123,924 rows, and does so in well under
the previous 116.74 seconds is **not** required — it may still take the full fetch time. Report the
elapsed time and the peak working set observed by `run_bounded.py`.

## Item B2 — Per-call query telemetry

**Goal.** Every catalog query call records what it cost, so scale problems are visible without
waiting for a crash.

**Where.** Same function as B1.

**Behaviour.** For every call, emit one log line at INFO:

```
catalog_query name=<name> rows=<n> elapsed_ms=<ms> params=<params>
```

**Do NOT** add this to the response payload, do not change any return shape, and do not change what
any query returns (master spec invariant 5).

**VERIFY.** Start the backend, load the dashboard, and paste the resulting log lines verbatim. That
paste is a deliverable of this round — it is the first end-to-end picture of what the app actually
asks the database for.

---

# Part C — The audit. Report only. Change nothing in this part.

This is the core of the round. The goal is to convert "we find one of these per round" into a single
list the operator can authorize against once.

## Item C1 — Materialization inventory

Find **every** call site in `app/` that obtains rows from the graph and holds them in Python. Include
at minimum every call to: `run_catalog_query`, `lookups.fetch_vertex_rows`,
`lookups.account_managed_map`, `lookups.advisor_rows`, `lookups.cohort_sids`, `lookups.month_ids`,
`lookups.advisor_names`, and any other `lookups.*` helper.

For each, report a row in this table:

| file:line | function | query called | filters passed | grain of result | bounded? |
|---|---|---|---|---|---|

- **filters passed** — the literal params. `{}` is a finding, state it as `{} — UNFILTERED`.
- **grain of result** — one row per what? (per account-month, per advisor, per month, per group)
- **bounded?** — yes only if the result size is bounded by something small and stated. "One row per
  advisor (5,455)" is bounded. "One row per account-month for a month" is not.

**Known members of this list, confirmed by review — your inventory must include them and must not
stop at them:**

1. `app/insights/exceptions.py` `_advisor_accounts` — `fetch_vertex_rows(V_AM, month=..., columns=...)`.
   Column projection present, **no row filter**. 3,123,924 rows for May, then a Python `GROUP BY`
   advisor with a `dict(row)` copy per row.
2. `app/insights/exceptions.py` line ~315 — for revenue-denominator rules, `_advisor_accounts(prior)`
   runs a **second time on the prior month**. Report whether both months can be resident at once.
   If so, the observed 5,553.39 MB is not the ceiling.
3. `app/graph/queries/lookups.py` `account_managed_map` — `run_catalog_query("account_managed_flags", {})`.
   No month, no advisor, **no filter of any kind**, docstring says "over every account". Report the
   actual row count this returns.
4. The rule population path reached from `app/rules/evaluator.py`.

## Item C2 — Real-scale row counts

For every **unbounded** row in the C1 table, obtain the actual row count at real scale. Get it from
TigerGraph directly (a count is cheap; do not fetch the rows to count them). Where you cannot obtain
it, write `UNKNOWN` and say what you tried — **do not estimate**.

## Item C3 — The missing third list from Amendment 2

Amendment 2 required three lists. Two were delivered: `installed without local source: []` and
`local source not installed: []`. Both are **name** comparisons.

Deliver the third: **installed queries whose body differs from the local `.gsql` source.** Compare
the installed body text against the local file for all 60. Report every mismatch with the query name
and a summary of the difference. This is read-only — do not install, edit or drop anything.

**Also report:** the local GSQL source count is 60 in this environment and 56 in the reference tree.
Name the four files present here that are not in the reference.

---

# Part D — Open questions from review. Report only, in Section 4 of your report.

Each of these is a specific unanswered question from the last two reports. Answer with exact command
output, or state plainly that you could not determine it.

**D1 · Month label off-by-one.** Item 2.5 printed `month_label: May 2026` immediately above
`compiler_params: {'month': '202606', ...}`. 202606 is June. Were these two different probes, or is
the label derivation off by one month? Show the derivation code and its output for 202604, 202605 and
202606.

**D2 · Cohort count discrepancy.** Item 2.5 printed `advisor_count: 5507 cohort_count: 5455`. What is
the 5,507 set, and which endpoints or views read it rather than the 5,455 cohort? The cohort is
5,455 by the client's definition — if any advisor-facing surface uses 5,507 that is an invariant 5
issue and must be flagged, not fixed in this round.

**D3 · `lookups.py`.** Report its **full path** and the **exact current signature** of
`fetch_vertex_rows`. Item 2.4's report said the evaluator fetches "including month, advisor, key,
**reason-code**, and column pushdowns", but the reference signature has no `reason_cd` parameter.
Either `lookups.py` was modified and omitted from the changed-file list, or the evaluator calls
`run_catalog_query` directly for that case. State which, and show the call site.

**D4 · Store-read arithmetic.** Phase 1's worklist was **58 direct-store lines across 10 modules**.
Item 2.6 converted **5 modules** and the STRICT guard then passed with zero. Reconcile these. Paste
`check_store_reads.py` STRICT output in full, including the list of files it inspects and the
patterns it matches.

**D5 · Guard blind spot.** The STRICT guard checks for reads *outside* `app/graph/`. The defect Item
2.4 found — `rules_evaluate.py` supplying a local store to the interpreter — is **inside**
`app/graph/queries/`. Explain how that path obtained a store in real mode without tripping Phase 1's
`get_foundation_store()` guard. If there is a construction path that bypasses that guard, name it and
list every file that uses it.

**D6 · Amendment 5.** The `CompileError` where the checker expected `compiled.plan`, and
`translate_plan` behind the Generate Query button. This appeared nowhere in the last report. State
its status: done in an earlier round, deferred, or not started.

**D7 · The two `evaluated=False` branches.** `evaluate_rule` returns `evaluated=False` from a
`CompileError` branch **and** from a runtime `except Exception` branch. Item 2.4 made
`insights/service.py` "raise for any other unevaluated outcome", which would now make a CompileError
raise. Paste the current body of `evaluate_rule` and the new guard clause in `insights/service.py`,
and state explicitly whether the two branches are handled separately.

**D8 · V0 seed dry run.** `ensure_v0_seed()` calls `validate_plan`, which executes plans, and it runs
at startup whenever no rule-set version exists. Phase 3 wipes the rule store. Run each of the seven
V0 seed rules through `validate_plan` **now**, without wiping anything, and report which pass and
which raise. **Do not fix any that fail** — report them. If any raise, Phase 3 would take the app
down at boot with no git to roll back from.

**D9 · The reconciliation gate.** Section 5 of the last report stated April firm-basis revenue as
$397,389,374.54 in prose, with no command. Paste the **exact command and its verbatim output**.

**D10 · Non-credited composition.** Item 2.2 reported 12 rows: one is `9R`, eight appear in the
unmapped list. List all 12 with code, value and label. Six codes appeared that are in no project
documentation (`91`, `92`, `9C`, `9L`, `9S`, `9Y`) — confirm them. And `98` did not appear at all
despite being named in Amendment 6 — state whether it has zero rows or is mapped elsewhere.

**D11 · Deterministic ordering.** `revenue_by_advisor` assigns `rank` from a Python
`sorted(..., key=lambda kv: -kv[1])` with no tie-break. Two advisors on identical `credited_amt` get
an arbitrary order that can change between runs. Master spec invariant 4 forbids this. Report every
place a rank, ordering or "top N" is produced, and whether each has an explicit deterministic
tie-break. **Report only — do not change ordering in this round**, since ordering is a client-facing
output.

**D12 · Duplicate float tails.** Item 2.3 reported `change_amt: 4965089.480000019`; Item 2.5 reported
`credited_change: 4965089.480000079`. Same figure, two float representations, two code paths. Name
both paths and state which is authoritative — master spec invariant 8 requires exactly one.

---

# Part E — GATED. Do not begin. Operator authorization required.

The remedy for the scale defect requires GSQL that does not exist: a per-advisor account-month
aggregate, and a bounded replacement for `account_managed_flags`. Master spec v1's escape hatch —
"it almost certainly means an installed query is not registered in the catalog" — is now closed,
because Item 2.2 reconciled the catalog completely (60 installed, 61 catalogued, one correct by
design).

**Therefore new GSQL is genuinely required, and this round does not authorize it.** Part C is the
evidence the operator reviews before authorizing it.

**Do not author, install, or draft GSQL in this round.** If Part C shows an installed query that
already covers one of these needs, that is a finding — report it in Section 4 and stop.

---

## Report

Write `docs/analysis/PHASE_2C_COMPLETE.md` in the master spec §9 format, with these additions:

- **Section 2** carries Items A1, A2, B1, B2, C1, C2, C3 with check/state/changed/verify each.
- **Section 4** carries D1 through D12, each answered or explicitly marked undetermined.
- **Section 5** must include the D9 command output verbatim, not a restatement.
- **Add a Section 8 — Materialization inventory**, containing the full C1 table and C2 counts. This
  is the deliverable the next round is built from. Do not summarize it.

## Stop conditions

Stop and report immediately, without attempting a workaround, if:

- Item A1 cannot be made to kill the process tree. Nothing else in this round is safe to run.
- Any item appears to require authoring GSQL.
- Any item appears to require adding `LIMIT`, sampling, or truncation.
- The B1 ceiling makes the application unable to start. That is a finding, not a bug to route around
  — report which query fires it at startup.
- Any client-facing figure changes. April firm-basis must remain $397,389,374.54.

A report reading "A and B done, C complete, four of twelve D items undetermined with evidence" is a
**success**. A report reading "everything fixed" would mean something was guessed.
