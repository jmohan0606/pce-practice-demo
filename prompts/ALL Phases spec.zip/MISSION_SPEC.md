# PCE Practice Demo — Mission Spec: Make the Application Work End to End

**This file supersedes `02C_SCALE_AUDIT_AND_ANSWERS.md` and phase files 02 through 05.** Read
`00_MASTER_SPEC.md` first for context and invariants, then this file. Where this file and master spec
§2 disagree about GSQL authoring, **this file wins** — see §2 below.

---

## 0 · Resume protocol — read this before anything else, every session

Sessions end when limits are hit. When that happens the work already done is **still done**. Redoing
it wastes hours and re-runs expensive real-data queries for no reason.

**The first thing you do in every session, before reading the rest of this file:**

1. Check whether `docs/analysis/MISSION_STATE.md` exists.
2. **If it exists, read it and trust it completely.** Every item marked `DONE` is finished. Do not
   re-check it, do not re-verify it, do not re-run its commands, do not re-read the files it touched.
   Start work at the item named on the `NEXT:` line.
3. **If it does not exist**, this is the first session. Create it, then begin at the first item.

**Do not re-verify completed work "to be safe."** If an item is `DONE`, its verification already
passed and its numbers are already recorded. Re-running a query that took 116 seconds and 3 GB in
order to confirm something you already confirmed is the single most wasteful thing you can do here.

### The state file

`docs/analysis/MISSION_STATE.md` — keep it short and machine-readable. Rewrite it **after every
item, before starting the next one**:

```markdown
# Mission State
BACKUP: DONE — C:\Users\R757680\ds\workspace\pce-practice-demo-main_phase2c_backup_20260825
NEXT: 4.3 account_managed_map filter

## Items
4.9  row ceiling           DONE   raises at 50000; caught 6 call sites
4.10 telemetry             DONE
4.1  _advisor_accounts     DONE   3123924 -> 5455 rows, 4.1s, 210MB, query pce_advisor_account_totals
4.2  prior-month load      DONE   reuses 4.1 query
4.3  account_managed_map   IN PROGRESS
4.4  firm exceptions N+1   TODO
...
```

One line per item. Status is `DONE`, `IN PROGRESS`, `TODO`, or `BLOCKED — <one-line reason>`. For
`DONE` items on data paths, keep the cost numbers on the line — those feed §7's cost table, so you
never need to re-measure to write the report.

**If a session ends mid-item**, the next session redoes only that one item. That is the maximum
acceptable loss.

### Backups — one only

**A full workspace copy is taken once, at the very start of the first session, and never again.**
Two copies already exist. Before copying anything, check the `BACKUP:` line in the state file and
check the workspace parent directory for an existing `*_backup_*` folder. If either shows a backup
exists, **do not make another one** — note it and move on. Repeated multi-gigabyte copies cost time
and disk for no benefit.

### Staying inside limits

- Work **one item at a time**. Finish it, update the state file, then start the next.
- **Do not re-read large files you have already read** in the session. Read the function you are
  changing, not the whole module.
- **Do not paste large outputs into your reasoning.** Record the numbers that matter — row count,
  elapsed, peak memory — and discard the rest.
- When you sense the session is running long, **stop cleanly**: finish the current item, update the
  state file, and say which item is next. A clean stop costs nothing. An abrupt one costs an item.

---

You have the live code and the live database. You are expected to **find the problems, fix them, test
them, and report only what you could not deliver.** Do not ask for permission item by item. Do not
produce an audit and stop. Previous rounds were structured as investigation followed by operator
review; that structure has cost more time than the defects themselves. This round is different.

---

## 1 · The goal

The application must work end to end against real client data without dying, without partial results,
and without invented numbers. Concretely, all six of these must be true when you are done:

| # | Must work | Proof required |
|---|---|---|
| 1 | Dashboard loads with real figures | Page returns 200; every tile populated; April firm-basis = **$397,389,374.54** |
| 2 | All nine published rules evaluate and return live outcomes | Each of the nine returns `evaluated=true` with a real match count |
| 3 | Firm Exceptions returns for the 5,455-advisor cohort | Completes in under 120s, under 2 GB peak |
| 4 | Documents & Rules page matches its mockup | Rule list, filters, delete, Generate Query, Preview all functional |
| 5 | Opportunities and Coaching populate | Advisor-scoped Opportunities return; Coaching renders |
| 6 | Nothing silently degrades | No mock data in real mode; no partial results; failures are loud |

Item 6 is not a nice-to-have. A dashboard that shows plausible wrong numbers is worse than one that
shows an error.

---

## 2 · Standing authorization — read this carefully

**You are authorized to author, install, and modify GSQL queries.** This reverses master spec §2,
which was written when the catalog was behind the database. It no longer is. The blocker now is that
queries the application genuinely needs **do not exist**, and no amount of catalog reconciliation
will conjure them.

**This includes modifying `rule_evaluation_rows`.** It is the row source for rule evaluation and it
currently returns raw account-month rows. It should return rows already aggregated at the plan's
grain with the plan's filters applied server-side. Change it.

Rules for GSQL work:

- **Use the installed 60 queries as your format reference.** Match their conventions exactly:
  projection form (not bare `PRINT`), `__vertex_id` aliasing, `TYPE name` parameter order, single-hop
  `SELECT`s rather than multi-hop patterns. GSQL V1 syntax, TigerGraph 4.2.2.
- **Name new queries with a `pce_` prefix** so they are identifiable as authored in this round.
- **Register every new query in the catalog** (`app/graph/queries/catalog.py`) with its declared
  column contract. A query that is installed but uncatalogued is invisible to the app.
- **Save the source** of every new or modified query to `docs/tigergraph/queries/<name>.gsql` so the
  local sources stay in sync with what is installed.
- **Never create a GSQL version of `rules_evaluate_plan`.** It is the Python plan interpreter and it
  takes an arbitrary plan structure that GSQL cannot accept as a parameter. This one prohibition
  stands. Its *row source* is `rule_evaluation_rows` — that is what you change.
- **Do not drop or replace an existing query without keeping the original.** If you must change one,
  save the prior body to `docs/tigergraph/queries/_superseded/<name>_<date>.gsql` first.

---

## 3 · The design principle — apply this everywhere, not just where I name it

> **TigerGraph computes. Python interprets and narrates. Move the question to the data, never the
> data to the question.**

If Python is looping over rows to compute something, that computation belongs in the database. This
holds regardless of how small the current result happens to be — every defect on this project was
invisible at 2,190 rows and fatal at 3.1 million.

**The worked example.** `_advisor_accounts` in `app/insights/exceptions.py`:

```python
managed = lookups.account_managed_map()          # every account in the firm, unfiltered
for row in lookups.fetch_vertex_rows(V_AM, month=month, columns="acct_key,advisor_sid,credited_amt"):
    r = dict(row)                                 # a copy of every one of 3,123,924 rows
    r["is_managed"] = managed.get(str(row.get("acct_key")), False)
    out.setdefault(str(row.get("advisor_sid")), []).append(r)   # GROUP BY, in Python
```

This fetches a whole month and groups it by advisor in a Python loop. It reached 5,553.39 MB. The
column projection is real but it narrows *columns*, not *rows* — that is not enough. The correct
shape is a query that groups by advisor server-side and returns roughly 5,455 rows.

**Now generalize it.** When you encounter any of the following, fix it the same way without asking:

| If you find | Do this |
|---|---|
| A `for` loop that sums, counts, averages, or accumulates query results | Push the aggregate into GSQL; return the aggregated rows |
| A `setdefault`/`defaultdict` pattern building groups from rows | That is a `GROUP BY`. Push it down |
| A query call passing `{}` or no filter, feeding something scoped | Add the filter as a query parameter |
| Two datasets fetched and joined by dict lookup in Python | Push the join into GSQL if the graph supports it; otherwise scope both sides |
| `sorted()` over query results to produce a rank or top-N | Order server-side. If ordering must stay in Python, give it an explicit deterministic tie-break |
| A call in a loop over advisors, months, or accounts | That is an N+1. Replace with one query returning all of them |
| A result larger than ~50,000 rows reaching Python | Wrong shape. Aggregate or filter it server-side |
| The same figure computed in two places | Pick one authoritative path; make the other call it |

**When the fix requires a new query, write the query.** That is what §2 authorizes.

---

## 4 · What is already known broken — start here, do not stop here

This is a head start from prior analysis, not a complete list. Find the rest yourself.

**Scale defects:**

1. `app/insights/exceptions.py::_advisor_accounts` — the worked example above. 3,123,924 rows, Python
   `GROUP BY`.
2. `app/insights/exceptions.py` line ~315 — for revenue-denominator rules, `_advisor_accounts(prior)`
   runs a **second time** on the prior month. Two months resident at once.
3. `app/graph/queries/lookups.py::account_managed_map` — `run_catalog_query("account_managed_flags", {})`.
   No month, no advisor, **no filter at all**. Docstring says "over every account."
4. `compute_firm_exceptions` evaluates rules **per advisor across 5,455 advisors** with the month's
   population resident. This is an N+1 and it does not improve when queries get faster. It needs to
   become one firm-grain pass.
5. `rule_evaluation_rows` returns raw rows. Modify it to return pre-aggregated rows at the plan's
   grain. Extend `translate_plan` in `app/rules/compiler.py` to emit query parameters (filters,
   aggregate, grain) rather than a row-by-row evaluation plan. **The trigger comparison, exclusion
   logic, and narrative stay in Python** — that is the interpreter and it does not move.

**Correctness defects:**

6. `month_label` printed `May 2026` next to `compiler_params month: '202606'`. 202606 is June. Find
   the derivation, determine whether it is off by one, fix it if so.
7. `advisor_count: 5507` against `cohort_count: 5455`. Determine what the 5,507 set is and which
   surfaces read it. Advisor-facing views must use the 5,455 cohort.
8. `revenue_by_advisor` assigns `rank` from a Python `sorted()` with no tie-break — non-deterministic
   between runs for equal amounts. Give it a deterministic order.

**Structural:**

9. Add a row-count ceiling in `run_catalog_query`: if a result exceeds `MAX_QUERY_ROWS` (default
   50,000), **raise** with the query name, row count, and params in the message. Never truncate,
   never sample, never add `LIMIT` to duck under it. This is your own regression detector — build it
   early and let it find the call sites you missed.
10. Add per-call telemetry at INFO: `catalog_query name=<n> rows=<n> elapsed_ms=<n> params=<p>`.
11. Run every long command through `scripts/run_bounded.py` (built and verified in Phase 2C). Default
    timeout 120s. It kills the process tree and reports peak working set.

**Blocking Phase 3, check before any reset:**

12. `ensure_v0_seed()` runs at startup when no rule-set version exists and calls `validate_plan`,
    which executes plans against data. Run all seven V0 seed rules through `validate_plan` **before**
    wiping anything. If any raise, fix them first — otherwise a reset leaves the app unable to start,
    with no git to roll back.

**Remaining feature work** — phases 4 and 5 as previously scoped: Documents & Rules page to
`docs/ui/MOCKUP_RULE_LIST_MANAGEMENT.html` and `MOCKUP_RULE_AUTHORING.html`; Generate Query
(depends on `translate_plan`, which item 5 touches); Approve All; Preview; Opportunities and
Coaching. The mockups are the contract — open them and match them.

**Known deferred:** `eci_id` is empty on all CRM opportunity rows, so household-scoped Opportunities
cannot work. Advisor-scoped must. Leave household scope deferred and say so.

---

## 5 · Non-negotiables

These are the only things you may not decide for yourself:

1. **No mock data in real mode.** Ever. The local CSV store must never serve a read outside mock/local mode.
2. **No partial results.** A figure is complete and correct, or absent with an error. Never a number
   computed from part of a population.
3. **Never change a client-facing figure to make something work.** Reason-code filters, cohort
   definition, `proc_dt` attribution, `__UNATTRIBUTED__` handling — these are the client's
   definitions. If a fix would move a number, **stop and report that one thing** and continue with
   the rest.
4. **No `LIMIT` without a deterministic `ORDER BY`.** No sampling, no approximation, no truncation.
5. **`rules_evaluate_plan` stays Python.**
6. **One workspace backup, ever.** See §0 — two copies already exist. Do not make more.

---

## 6 · How to work

**Decide and continue.** If you find a defect not listed in §4, fix it under §3's principle and
record the decision in your report. Do not stop to ask. The two exceptions are in §5.3 (a change that
would move a client-facing figure) and anything that deletes data.

**Test as you go, at real scale.** A fix verified against a small filtered result proves nothing about
the real population. For every fix to a data path, record three numbers: rows returned, elapsed
seconds, peak working set. A fix without those three numbers is unverified.

**Reconcile continuously.** After any change touching revenue, re-run the April firm-basis check. If
it is not $397,389,374.54, you have broken something — find it before moving on.

**Update `docs/analysis/MISSION_STATE.md` after every item, before starting the next.** See §0. This
is what makes an interrupted session cost one item instead of a whole round.

**Work in stages. Stop at every checkpoint.** Each stage unblocks the next, and each ends with a
checkpoint where you write a short report and **wait for the operator to say proceed.**

| Stage | Work | Covers | Checkpoint |
|---|---|---|---|
| **1** | Row ceiling and telemetry (§4.9, §4.10) | — | **CP1** |
| **2** | Scale fixes (§4.1–4.4) — Exceptions path and lookups | Phase 2 | **CP2** |
| **3** | Rule path (§4.5) — `rule_evaluation_rows`, `translate_plan` | Phase 2 | **CP3** |
| **4** | Correctness fixes (§4.6–4.8), then V0 seed validation (§4.12) | Phase 2 | **CP4 — mandatory gate** |
| **5** | Reset (Phase 3), then Documents & Rules UI | Phases 3, 4 | **CP5** |
| **6** | Opportunities and Coaching | Phase 5 | **Final report** |

Build the detector in stage 1 before the fixes, so it finds the call sites §4 missed.

### At every checkpoint

1. **Leave the code working.** No half-applied change, no partially rewired call site, no query
   installed but uncatalogued. If you are mid-item when a stage ends, finish that item first. The
   operator must be able to run the app at every checkpoint.
2. Confirm the backend and frontend still respond.
3. Write `docs/analysis/CHECKPOINT_<n>.md` in the format in §7.
4. Update `MISSION_STATE.md` with `AWAITING REVIEW: CP<n>`.
5. **Stop. Do not begin the next stage.** Wait for the operator.

### CP4 is a hard gate

Stage 5 begins with the Phase 3 reset, which deletes the rule store and **cannot be undone** — there
is no git here. Before it runs, the operator must have seen that all seven V0 seed rules pass
`validate_plan`, because `ensure_v0_seed()` runs at startup once the store is empty and a failing
seed plan leaves the app unable to start.

**Do not perform the reset without explicit operator approval at CP4.** If any V0 rule fails
validation, fix it and re-report before proceeding.

---

## 7 · Reports — exceptions only

**Do not narrate what worked.** The operator's time is the scarcest resource on this project. A full
item-by-item report costs more than it returns.

### Checkpoint reports

At each checkpoint write `docs/analysis/CHECKPOINT_<n>.md`. **Keep it under one page.** This is a
progress gate, not a document:

```markdown
# Checkpoint <n> — <stage name>

## Goals affected
Only the §1 goals this stage touched. PASS / FAIL / PARTIAL, with the number that proves it.

## Cost
Data paths fixed this stage: before rows -> after rows, elapsed, peak memory. One line each.

## Judgement calls
Defects found that were not in §4, and how you fixed them. One line each.
Anything you changed that touched a design decision — flag it so the operator can object.

## GSQL
Queries authored or modified this stage, one line each with purpose and real-scale row count.

## Blocked or broken
Anything not working, with what you tried. If nothing, write "nothing".

## App state
Backend and frontend responding? Any endpoint now raising, and why?

## Next
The stage you will start once approved.
```

At **CP4** add one extra section:

```markdown
## V0 seed validation — required before reset
All seven V0 seed rules through validate_plan. Name each and its result.
State plainly whether the reset is safe to perform.
```

### Final report

After stage 6, write `docs/analysis/MISSION_COMPLETE.md`:

```markdown
# Mission Report

## 1. Goal state — the six checks
A six-row table: each goal from §1, PASS or FAIL, with the number that proves it.
For any FAIL, one line on what blocks it.

## 2. What I could not deliver
Only genuine failures. For each: what you tried, what it returned, what you would need.
Be specific. This is the section the operator reads first.

## 3. Judgement calls I made
Defects you found that were not in §4, and how you fixed them. One line each.
Also: anything you fixed that touched a design decision, so the operator can object if wrong.

## 4. GSQL authored or modified
Every query created or changed, with its purpose and its row count at real scale.

## 5. Numbers
April firm-basis revenue — command and verbatim output. Must be $397,389,374.54.
Any client-facing figure that moved, and why.

## 6. Cost table
For every data path you fixed: before and after rows, elapsed seconds, peak working set.

## 7. App state
Backend and frontend URLs, both confirmed responding. Any endpoint still raising, and why.
```

Everything that worked, worked. Do not write it up.

---

## 8 · What success looks like

Six PASS rows in §1, a short §2 naming the two or three things that genuinely defeated you, and a §6
cost table showing row counts dropping by three orders of magnitude.

If you deliver four of six and §2 explains the other two with evidence, that is a good outcome. If
you deliver six of six by loosening a filter, capping a result, or letting a partial number through,
that is a failure that will surface in front of the client.
