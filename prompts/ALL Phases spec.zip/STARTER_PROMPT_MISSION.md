# Starter Prompt — Mission Round

Place `MISSION_SPEC.md` in `docs/spec/` alongside `00_MASTER_SPEC.md`. Then paste the block below.

---

> Read `docs/spec/00_MASTER_SPEC.md` for context and invariants, then read
> `docs/spec/MISSION_SPEC.md` in full. The mission spec supersedes `02C_SCALE_AUDIT_AND_ANSWERS.md`
> and phase files 02 through 05 — ignore those.
>
> Your job is to make the application work end to end against real client data. Six concrete goals
> are listed in §1 of the mission spec. **Find the problems, fix them, test them at real scale, and
> report only what you could not deliver.** Do not produce an audit and stop. Do not ask for
> permission item by item.
>
> **You are authorized to author, install and modify GSQL**, including modifying `rule_evaluation_rows`
> so it returns rows pre-aggregated at the plan's grain. Use the installed 60 queries as your format
> reference and match their conventions exactly. Prefix new queries with `pce_`, register them in the
> catalog with their column contracts, and save the source to `docs/tigergraph/queries/`. The one
> exception: never create a GSQL version of `rules_evaluate_plan` — it is the Python plan interpreter
> and must stay Python. You change its row source, not the interpreter.
>
> **The principle to apply everywhere:** TigerGraph computes, Python interprets and narrates. If
> Python is looping over rows to compute something, that computation belongs in the database. §3 of
> the mission spec has the worked example — `_advisor_accounts` fetching 3,123,924 rows and grouping
> them by advisor in a Python loop — and a table of the patterns it generalizes to. **When you find
> something like it that is not on my list, fix it the same way and tell me in §3 of your report.**
> Do not stop to ask. Column projection alone is not enough: narrowing columns while returning three
> million rows is still the defect.
>
> §4 of the mission spec lists twelve known defects as a head start. It is not the complete list.
> Build the row-count ceiling first (§4.9) — it raises above 50,000 rows and will find the call sites
> I missed. Never truncate, sample, or add `LIMIT` to duck under it.
>
> **Work in the six stages in §6 and stop at every checkpoint.** At each one, leave the code in a
> working state — no half-applied changes — confirm both services respond, write a one-page
> `docs/analysis/CHECKPOINT_<n>.md` in the §7 format, mark `AWAITING REVIEW` in the state file, and
> **stop. Do not begin the next stage until I tell you to proceed.**
>
> **CP4 is a hard gate.** Stage 5 starts with the Phase 3 reset, which deletes the rule store and
> cannot be undone — there is no git here. Show me all seven V0 seed rules passing `validate_plan`
> and wait for my approval before performing it.
>
> Only two things require you to stop mid-stage rather than decide: a change that would move a
> client-facing figure, and anything that deletes data. Everything else, use your judgement and
> record it.
>
> Test at real scale as you go. For every data-path fix, record rows returned, elapsed seconds, and
> peak working set — a fix without those three numbers is unverified. Run long commands through
> `scripts/run_bounded.py`. Re-check April firm-basis revenue after anything touching revenue; it must
> stay $397,389,374.54.
>
> Follow §0 exactly. Check `docs/analysis/MISSION_STATE.md` first — if it exists, trust it and resume
> at its `NEXT:` line without re-verifying anything marked DONE. Rewrite it after every item before
> starting the next. Two workspace backups already exist; do not make another one.
>
> Write a one-page `CHECKPOINT_<n>.md` at each checkpoint, and
> `docs/analysis/MISSION_COMPLETE.md` after stage 6 — both in the §7 formats. **Do not narrate what
> worked.** Report the goal checks, what defeated you, the judgement calls you made, the GSQL you
> wrote, the numbers, and the cost table. Everything that worked, worked; leave it out.
>
> Leave the backend on 127.0.0.1:8002 and the frontend on 127.0.0.1:3002, both responding.

---

## Resume prompt — paste this instead of clicking "Continue"

Clicking Continue makes Copilot re-read the original prompt and start over. Paste this instead:

> Resume the mission round. Read `docs/analysis/MISSION_STATE.md` **first** and trust it completely —
> everything marked DONE is finished and verified. Do not re-check it, do not re-run its commands, do
> not re-read the files it touched. A backup already exists; do not make another.
>
> Start at the item on the `NEXT:` line. Re-read only `docs/spec/MISSION_SPEC.md` §3 (the design
> principle) and the §4 entry for that item — you do not need the rest of the file again.
>
> Work one item at a time, update the state file after each, and stop cleanly if the session runs
> long rather than being cut off mid-item.

---

## Proceed prompt — paste after reviewing a checkpoint

> Checkpoint approved. Resume the mission round.
>
> Read `docs/analysis/MISSION_STATE.md` first and trust it completely — everything marked DONE is
> finished and verified. Do not re-check it, do not re-run its commands, do not re-read the files it
> touched. A backup already exists; do not make another.
>
> Begin the next stage from the `NEXT:` line. Re-read only `docs/spec/MISSION_SPEC.md` §3 (the design
> principle) and the §4 entries for that stage — you do not need the rest of the file again.
>
> Work one item at a time, update the state file after each, and stop at the next checkpoint.
