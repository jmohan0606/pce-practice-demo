# PCE Practice Demo — Master Spec for Fix Rounds

**Read this file first, every session, before any phase file.** It carries the rules that apply to
every phase. The phase file tells you *what* to do; this file tells you *how* to do it and what you
must never do.

---

## 1 · What this application is

A demo for a wealth-management client. It reads compensation plan documents, extracts rules from them
with an LLM, evaluates those rules against a TigerGraph graph of revenue data, and generates narrative
insights.

**The governing principle:**

> **TigerGraph computes the numbers. Python interprets and narrates. The AI never computes a figure.**

Every number on screen traces to a query result or a document citation.

---

## 2 · State of the system

**Data is loaded and reconciles.** TigerGraph holds 40,047,519 vertex rows and 104,273,975 edge rows.
April firm-basis revenue is **$397,389,374.54** against the client's own PCE report of
$403,533,981.62 — the $7.6M gap is advisors outside the cohort, verified.

| | |
|---|---|
| Scope | April–June 2026, dated by **`proc_dt`** |
| Cohort | **5,455 advisors** by the client's definition |
| Transactions | **12,360,142** |
| NULL-advisor rows | 4,136,967 under a synthetic `__UNATTRIBUTED__` — counted firm-wide, excluded from advisor views |
| Firm reason filter | excludes `9X`, `XX` |
| Advisor reason filter | also excludes `9R`, `98`, `99`, `9H` |

**The firm total does not equal the sum of advisors, and that is correct.**

**TigerGraph is ahead of the application.** 60 queries are installed, including the correct
projection-form `rule_evaluation_rows` (15 bracketed PRINTs, 15 `AS __vertex_id` aliases, `reason_cd`
pushdown). **No GSQL authoring work is required in any phase.** If a phase seems to need a new GSQL
query, stop and report — it almost certainly means an installed query is not registered in the
catalog.

**The deployed application is behind.** Round 9's catalog layer is absent (all five catalog markers
count 0, `lookups.py` does not exist, catalog has 46 entries against 60 installed). Rounds 10 and 11
are present.

**A completed demo was run from this environment.** Some files here contain fixes that exist nowhere
else. **This environment is the source of truth, not any reference tree.**

---

## 3 · Hard invariants — never violate these

1. **No mock data in real mode, ever.** The local CSV store (`FoundationGraphStore`) must never serve
   a read when `graph_client_mode` is not `mock` or `local`.
2. **No whole-table loads into Python.** Filtering, aggregation and projection happen in TigerGraph.
   Python receives small filtered results. A read returning six figures of rows is a bug in the
   pushdown, not an acceptable cost.
3. **Refuse, never silently degrade.** A crash is better than a wrong number. A loud refusal naming
   the query is better than both. **No `LIMIT` without a deterministic `ORDER BY`, no sampling, no
   approximate aggregates, no truncation-with-a-warning.** A cap that *raises* is fine.
4. **Never change what a query returns to make something work.** Do not touch reason-code filters,
   `__UNATTRIBUTED__` handling, `proc_dt` attribution, or cohort definition. If a fix would alter a
   client-facing figure, **stop and report before making it**.
5. **`rules_evaluate_plan` is Python, by design.** It is the plan interpreter — it takes a compiled
   plan (filters, aggregate, trigger, grain) and evaluates it. GSQL cannot accept an arbitrary plan
   structure as a parameter. **Never attempt to install it as a GSQL query.** Its *row reads* go to
   the installed `rule_evaluation_rows`.
6. **Content over timestamps.** File modification times reflect when files were copied, not what is in
   them. A file labelled "newer" has been observed running older code. Judge by markers and content
   only.
7. **Approved/published rules are never silently deleted.** They may be superseded or deactivated.

---

## 4 · The verify-before-change protocol

**For every change in every phase:**

1. **CHECK** — run the stated check command. Record the exact output.
2. **COMPARE** — does current state already match the target?
   - **Matches** → record "already correct", change nothing, move on.
   - **Does not match, and the phase file states the fix** → apply the fix.
   - **Does not match, and the phase file states only a goal** → diagnose, then fix (see §5).
3. **VERIFY** — re-run the check. Record the exact output. If it still does not match, **stop and
   report**. Do not attempt a second, different fix without reporting the first failure.

**Never change a file you have not first checked.** Never assume a previous phase left something in a
particular state — re-check it.

---

## 5 · When the cause is unknown

Some phase items state a **goal and an acceptance test** but not a fix, because nobody has diagnosed
them yet. For these:

1. Diagnose first. Trace the code path. Read the actual response. Report what you find.
2. **If you find the cause, fix it**, and state the cause in the completion report.
3. **If you cannot determine the cause, STOP AND REPORT.** Do not guess. Do not implement a
   plausible-looking fix for an undiagnosed problem. Write what you tried, what you observed, and
   what you would need in order to proceed.

A phase that reports "three fixed, two undiagnosed with evidence attached" is a **success**. A phase
that reports "five fixed" where two were guesses is a failure that will cost more later.

---

## 6 · Operating rules

- **Report exact commands and exact output.** Paste output verbatim, including errors. Never
  paraphrase output in place of showing it.
- **If something cannot be measured, say so.** Do not substitute a different measurement.
- **A zero is a finding.** A count of 0, an empty result, a missing table — investigate it.
- **One change at a time**, verified, before the next.
- **Never leave an orphaned process running.** If a command exceeds 60 seconds, stop it and record
  that you stopped it and at what elapsed time.
- **Do not run anything that loads the local CSV store** until Phase 1's guard is in place. It is a
  multi-gigabyte load that has crashed this machine.

---

## 7 · Keep the application running

After each phase, leave both services running so the operator can test:

```bat
:: backend
uv run uvicorn app.api.main:app --host 127.0.0.1 --port 8002 --reload

:: frontend
cd frontend && npm run dev
```

Report the URLs and confirm both respond. If a phase leaves the app unable to start, **say so
prominently at the top of the completion report** and state exactly why.

**Expect loud failures after Phase 1.** Endpoints that currently read local CSVs will start raising.
That is the correct and intended state — they are serving mock data today. Do not suppress those
errors to keep the app quiet.

---

## 8 · Completion report format

At the end of each phase, write `docs/analysis/PHASE_<n>_COMPLETE.md` with **exactly these sections**:

```markdown
# Phase <n> Complete — <title>

## 1. Status
One block. What was fixed, what was already correct, what is undiagnosed, what is blocked.
No recommendations here.

## 2. Items
One subsection per numbered item in the phase file. Each with:
  - **Check command and exact output** (before)
  - **State found**: already correct / fixed / undiagnosed / blocked
  - **What was changed** — exact files and what changed in each. "None" if nothing.
  - **Verify command and exact output** (after)

## 3. Files changed
Complete list, one per line, full relative path. This is how the operator reviews the diff.

## 4. What I could not do
Every item that failed, timed out, or could not be diagnosed. What you tried, what it returned,
and what you would need to proceed. Be specific.

## 5. Numbers check
Confirm no client-facing figure changed. If any did, state which and why.
Where the phase touches revenue, confirm April firm-basis is still $397,389,374.54.

## 6. App state
Backend URL, frontend URL, both confirmed responding. Any endpoint now raising, and why.

## 7. Ready for next phase
Yes / No. If no, what blocks it.
```

---

## 9 · Phase index

| Phase | File | Goal |
|---|---|---|
| 1 | `01_PHASE_1_LOCAL_STORE_GUARD.md` | Stop the memory crash; end mock data in real mode |
| 2 | `02_PHASE_2_CATALOG_AND_RULES.md` | Catalog reconciled; rules evaluate; citations return |
| 3 | `03_PHASE_3_DELETE_AND_RESET.md` | Delete controls with cascade; clean slate |
| 4 | `04_PHASE_4_DOCUMENTS_AND_RULES_UI.md` | Documents & Rules page rebuilt to mockup |
| 5 | `05_PHASE_5_OPPORTUNITIES_AND_COACHING.md` | Opportunities and Coaching populated |

**Run them in order.** Each assumes the previous completed. Do not start a phase until the operator
has reviewed the previous completion report and said to proceed.

---

## 10 · The mockups are the UI spec

They are in the repository at `docs/ui/`:

| File | Covers |
|---|---|
| `MOCKUP_ROUND_A_DASHBOARD.html` | Dashboard, drivers, exceptions, non-credited, citations |
| `MOCKUP_RULE_LIST_MANAGEMENT.html` | Documents & Rules — rule list, grouping, filters, delete |
| `MOCKUP_RULE_AUTHORING.html` | Write a Rule, Generate Query, Preview, Retry, document upload |
| `MOCKUP_RULE_VERSIONS.html` | Version history |
| `MOCKUP_DRILLDOWN.html` | Evidence drill-down tables |
| `MOCKUP_CHAT.html` | Chat |
| `MOCKUP_FEATURE_FLAGS.html` | Feature flags |

**Where a phase file references a mockup, open it and match it.** The mockups are contract specs —
they state API shapes and behavioural rules, not just layout. The current UI has drifted from them
over recent rounds; the mockup is correct and the current UI is not.
