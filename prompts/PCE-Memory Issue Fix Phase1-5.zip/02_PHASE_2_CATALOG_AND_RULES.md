# Phase 2 — Catalog Reconciliation and the Rules Path

**Read `00_MASTER_SPEC.md` first.** Phase 1 must be complete and reviewed.

**Goal:** every production read goes to TigerGraph through the catalog; rules evaluate instead of
silently returning zero; lifecycle counts, citations, and non-credited detail all return.

This phase fixes the largest number of visible defects because they share one root cause.

---

## Evidence behind this phase

**The catalog is behind the database.**

| | |
|---|---|
| Catalog entries (deployed) | **46** |
| Installed in TigerGraph | **60** |
| Catalog names with no installed query | **0** |
| Installed but never called by the app | **14** |

The 14 unused: `account_managed_flags`, `aum_managed`, `non_credited_by_cause`,
`noncredited_discount_detail`, `noncredited_eligibility_detail`, `noncredited_household_detail`,
`noncredited_inheritance_detail`, `pce_dashboard_advisors`, `pce_dashboard_months`,
`pce_dashboard_product_contribution`, `pce_dashboard_transitions`, `product_advisor_ranking`,
`product_group_master`, `rule_evaluation_rows`.

**Two column contracts are false:** `advisor_totals` declares `change_pct` but does not serve it;
`revenue_by_advisor` declares `rank` but does not serve it.

**The rules path is broken at one line.** Traced exactly:

```
insights/service.py:189      → evaluate_published_rules
insights/service.py:76-79    → evaluate_rule_set
rules/service.py:237-239     → evaluate_rule per rule
rules/service.py:145         → _run_plan
rules/service.py:105-107     → run_query("rules_evaluate_plan", {plan, params})
rules/service.py:146-148     → catches the 404, converts to evaluated=False, matched=[], matched_count=0
insights/service.py:96       → if not (evaluated and matched): continue   ← skips it
```

`RSV_v4` has **nine active published rules**, all PUBLISHED, all `active=True`.
`rules_evaluate_plan` appears in **neither** the 46-entry catalog **nor** the 60 installed queries.
The installed rule-row query is `rule_evaluation_rows`, in the correct projection form.

---

## Item 2.1 — Restore the catalog layer

**CHECK**

```bat
uv run python -c "from app.graph.queries.catalog import CATALOG; print('catalog entries:',len(CATALOG))"
if exist app\graph\queries\lookups.py (echo lookups PRESENT) else (echo lookups ABSENT)
findstr /C:"LOCAL FALLBACK tier" /C:"_normalize_rule_evaluation_rows" /C:"local_compute" /C:"RULE_EVALUATION_VERTICES" app\graph\queries\catalog.py
```

**Target:** `lookups.py` present; all four markers present; catalog registers every installed query.

**FIX** — copy from `reference\codespace_latest\`, **only these files**:

- `app/graph/queries/catalog.py`
- `app/graph/queries/lookups.py`
- `scripts/check_rule_rows_contract.py`

**Before overwriting `catalog.py`, diff it against the reference and record any deployed-only content
in the report.** The deployed tree contains demo fixes that exist nowhere else. If the deployed
`catalog.py` has entries or logic the reference lacks, **preserve them** — merge, do not overwrite
blindly. If you cannot tell whether something is a demo fix or stale, **stop and report**.

**VERIFY**

```bat
uv run python -c "from app.graph.queries.catalog import CATALOG; print('catalog entries:',len(CATALOG))"
uv run python scripts\check_rule_rows_contract.py
```

---

## Item 2.2 — Reconcile the catalog against what is installed

**The database is the source of truth.** The catalog must register every installed query the
application needs.

**CHECK**

```bat
uv run python -c "from app.graph.tiered_client import PyTigerGraphClient; from app.graph.queries.catalog import CATALOG; q=PyTigerGraphClient()._connection().getInstalledQueries(fmt='py'); inst=set(k.rsplit('/',1)[-1] for k in q); cat=set(CATALOG); print('installed:',len(inst)); print('catalog:',len(cat)); print('catalog missing installed:',sorted(cat-inst)); print('installed not in catalog:',sorted(inst-cat))"
```

**Target:** `catalog missing installed` is empty. `installed not in catalog` should contain only
queries the app genuinely does not use.

**FIX** — register the unused installed queries in `CATALOG`, with parameters and return columns
matching the **installed query body**. Get the body with:

```bat
uv run python -c "from app.graph.tiered_client import PyTigerGraphClient; print(PyTigerGraphClient()._connection().showQuery('<name>'))"
```

**Priority — these five drive the Non-Credited Revenue section, which currently shows reason codes as
`UNKNOWN (9R)` and produces no drill-down table on View:**

- `non_credited_by_cause` — supplies the cause labels
- `noncredited_discount_detail`
- `noncredited_eligibility_detail`
- `noncredited_household_detail`
- `noncredited_inheritance_detail`

`app/graph/queries/noncredited.py` already exists in the deployed tree — the module is there, the
registration is missing.

**VERIFY** — re-run the check. Then exercise the non-credited path:

```bat
uv run python -c "from app.graph.queries.catalog import run_catalog_query as q; r=q('non_credited_by_cause',{'month_id':'202605'}); print('rows:',r['row_count']); print(r['rows'][:3])"
```

**Expect:** named causes, not `UNKNOWN`.

---

## Item 2.3 — Fix the two false column contracts

**CHECK**

```bat
uv run python -c "from app.graph.queries.catalog import CATALOG,run_catalog_query as q; [ (lambda r,n: print(n,'served:',sorted(set().union(*(x.keys() for x in r['rows']))) if r['rows'] else [], 'declared:',sorted(CATALOG[n]['returns'])))(q(n,p),n) for n,p in [('advisor_totals',{'advisor':'all','from_month':'202604','to_month':'202605'}),('revenue_by_advisor',{'month_id':'202605','mode':'rows','limit':1})] ]"
```

**Target:** served columns include every declared column.

**FIX** — for each mismatch, choose **one**:

- **The consumer needs it** → compute it in the query or the shape layer. **`change_pct` and `rank`
  are derived values. Reproduce the previous derivation exactly.** If you cannot establish what the
  previous derivation was, **stop and report** — do not invent one. A different derivation is a
  changed client-facing figure.
- **The consumer does not need it** → remove it from the declared `returns`.

State which you chose and why, per column.

---

## Item 2.4 — Fix the rules path

Two changes. **Read invariant 5 in the master spec before starting.**

### 2.4a — `rules_evaluate_plan` becomes an internal local-compute entry

**CHECK**

```bat
uv run python -c "from app.graph.queries.catalog import CATALOG; s=CATALOG.get('rules_evaluate_plan'); print('registered:', bool(s)); print(s)"
findstr /N /C:"rules_evaluate_plan" app\rules\service.py
```

**Target:** `rules_evaluate_plan` is a `CATALOG` entry with `internal: True` and `local_compute: True`.
It executes in Python and is **never dispatched to TigerGraph**. Its row reads go through
`rule_evaluation_rows`.

**FIX**

- Register `rules_evaluate_plan` in `CATALOG` as internal + local_compute.
- `app/rules/service.py:105-107` calls it through `run_catalog_query(..., allow_internal=True)` rather
  than dispatching to the graph client.
- Confirm the evaluator's row reads use `lookups.fetch_vertex_rows` →`rule_evaluation_rows`, with
  `month` / `advisor_sid` / `reason_cd` / `columns` pushed down.

**Do not create a GSQL query named `rules_evaluate_plan`.** If any step seems to require one, stop and
report.

### 2.4b — Errors raise instead of becoming zero

**CHECK**

```bat
findstr /N /C:"except Exception" app\rules\service.py
findstr /N /C:"evaluated" app\insights\service.py
```

**Target:** a query failure in rule evaluation **raises**. It is never converted to
`evaluated=False, matched=[], matched_count=0` and then skipped.

**FIX**

- `app/rules/service.py:146-148` — let the exception propagate, or re-raise with context naming the
  rule and the query. Do not return a zero-valued outcome for a failed evaluation.
- `app/insights/service.py:96` — `if not (evaluated and matched): continue` must not swallow an
  errored rule. A rule that **evaluated successfully and matched nothing** may be skipped. A rule that
  **errored** must surface — to the job, the API, and the UI.

Distinguish the two cases explicitly. This is the difference between "no accounts were lost in May"
and "we could not tell whether any accounts were lost."

**VERIFY**

```bat
uv run python -c "from app.rules.store import get_rule_store; from app.insights.service import evaluate_published_rules; v=get_rule_store().latest_version('PUBLISHED'); f,o=evaluate_published_rules('all','202604','202605',v); print('rule_findings:',len(f)); print('outcomes:',len(o)); [print(' ',x.get('rule_code'),'evaluated=',x.get('evaluated'),'matched=',x.get('matched_count'),'err=',str(x.get('error'))[:90]) for x in o]"
```

**Expect:** `evaluated=True` with real match counts. **Any remaining `evaluated=False` with an error is
a failure of this item — report it, do not paper over it.**

---

## Item 2.5 — Convert the Exceptions path

**CHECK**

```bat
findstr /s /n /c:"get_foundation_store(" /c:"all_vertices" app\insights\exceptions.py
```

**Target:** zero hits. Phase 1's guard means these currently raise.

**FIX** — convert `_store()`, `_cohort_sids()`, `_advisor_accounts()`, `_advisor_names()` to
`lookups.fetch_vertex_rows`. Push `month` and `advisor_sid` down; project only the columns actually
used.

**A read here must return hundreds of rows, not millions.** If a converted read returns six figures,
the pushdown is wrong — fix it, do not accept it.

**VERIFY**

```bat
uv run python -c "from app.insights.exceptions import compute_firm_exceptions as f; r=f('202605'); print('rules:',len(r.get('rules') or [])); print('published_version:',r.get('published_version'))"
```

Then re-run the Phase 1 Item 1.4 memory probe. **Expect a completed response with flat memory.**

---

## Item 2.6 — Convert the remaining production local reads

Work the list captured in Phase 1 Item 1.3. For each production read site, convert to
`lookups.fetch_vertex_rows` or an appropriate catalog query.

**Leave alone:** anything inside `app/graph/` (the mock tier itself), tests, and scripts.

**VERIFY**

```bat
uv run python scripts\check_store_reads.py
```

**Expect:** PASS. If some sites cannot be converted, **report them individually with the reason** —
do not change the script's baseline to make it pass.

---

## Item 2.7 — Confirm the visible results

These are the user-facing outcomes of this phase. Check each and record the result.

1. **Lifecycle counts.** `NEW_ACCOUNT`, `LOST_ACCOUNT`, `RETAINED_ACCOUNT`,
   `ACCOUNT_TRANSFERRED_IN/OUT` return non-zero (or a stated, evaluated zero) in the dashboard sidebar
   and on the Advisor AI Insights page.
   **These are rule-driven by design.** Per `MOCKUP_ROUND_A_DASHBOARD.html`, each tile names its rule —
   e.g. *"Rule: New Billing"*, *"Rule: Lost Account"*. Confirm the label renders.
2. **Citations.** A generated insight links its rule and source document as evidence. The mockup
   shows: *"Rule: Sharing a Client Fee Discount · PCA · p. 4 · Discount…"* and a *"Real Evidence
   table"* link on drivers. Confirm the chain appears.
3. **Non-Credited Revenue.** Reason codes render with names, not `UNKNOWN (9R)`. The **View** button on
   a line item opens a detail table.

For each: record the endpoint, the response, and whether it matches the mockup.

---

## Acceptance for Phase 2

- [ ] `lookups.py` present; all four catalog markers present
- [ ] `catalog missing installed` is empty
- [ ] `advisor_totals` and `revenue_by_advisor` column contracts true
- [ ] All nine published rules return `evaluated=True`
- [ ] A rule query failure **raises**; it never becomes a silent zero
- [ ] `check_store_reads.py` passes, or every exception is individually justified
- [ ] Exceptions completes with flat memory
- [ ] Lifecycle tiles populated **and labelled with their rule**
- [ ] Citations present on findings
- [ ] Non-credited reason codes named; View opens a table
- [ ] **April firm-basis is still $397,389,374.54** — verify and state the figure
- [ ] Backend and frontend running

---

## Do not, in this phase

- Create any GSQL query
- Change reason-code filters, `__UNATTRIBUTED__` handling, `proc_dt` attribution, or cohort definition
- Invent a derivation for `change_pct` or `rank`
- Convert a failed rule evaluation into a zero
- Overwrite deployed files without first diffing and preserving demo fixes
- Touch the Documents & Rules UI — that is Phase 4
