# Phase 4 — Documents & Rules Page

**Read `00_MASTER_SPEC.md` first.** Phase 3 must be complete and reviewed.

**This phase is different.** Several items state a **goal and an acceptance test** but not a fix,
because nobody has diagnosed them. **Read master spec §5 before starting.** If you cannot determine a
cause, stop and report. Do not implement a plausible-looking fix for an undiagnosed problem.

**The mockups are the spec:**
- `docs/ui/MOCKUP_RULE_LIST_MANAGEMENT.html` — rule list, grouping, filters, delete
- `docs/ui/MOCKUP_RULE_AUTHORING.html` — upload, extraction offer, Generate Query, Preview, Retry

Open them. They state API shapes and behaviour, not just layout. The current UI has drifted from them
over recent rounds; **the mockup is correct and the current UI is not.**

---

## Item 4.1 — Remove the per-row category dropdown ✅ fix known

**Two dropdowns exist. Only one is removed.**

- **Per-row category dropdown in the document list** (PLAN / FAQ / GUIDANCE / PLAYBOOK / TRAINING /
  OTHER) — reverts to OTHER whatever is selected. **REMOVE THIS.**
- **Category selection in the upload dialog** — per mockup, *"Category at upload (defaults PLAN)"*.
  **KEEP AND FIX THIS.** It is the extraction gate.

**Target:** category is chosen once at upload and displayed in the row as a **static chip**, not an
editable control.

**The gate is unchanged: only PLAN and FAQ feed the Rule Extractor.** Every other category is indexed
for insights, coaching, and chat — never extracted.

**VERIFY** — upload a document as PLAN, confirm the row shows a static PLAN chip with no dropdown.
Upload one as GUIDANCE, confirm it is indexed and offers no extraction.

---

## Item 4.2 — Extract button on upload ✅ fix known

**Target**, per mockup:

> *"This category feeds the Rule Extractor — run extraction now?"* → **[Run extraction] [Not now]**

**It never auto-runs.** The operator decides.

Shown only for PLAN and FAQ. Other categories show `Indexed` and no offer.

**VERIFY** — upload a PLAN document, confirm the offer appears and extraction runs only on click.

---

## Item 4.3 — Extraction count dropdown ⚠️ diagnose then fix

**Symptom:** selecting 5 / 10 / 20 has no effect. A 15-page document produced 100+ rules. The rule
store had accumulated **163 rules** before the reset.

**Goal:** select N, get **at most** N rules.

**Diagnose:** trace the count from the UI control → API request → extractor. Find where it is dropped.
Likely candidates: not sent in the request body; not read by the endpoint; not passed to the
extraction agent; passed but not enforced in the prompt or the post-processing.

**Report the exact point at which it is lost.**

**When you fix it, enforce the cap deterministically in code**, not only in the LLM prompt. A prompt
instruction is a request; a code cap is a guarantee. If the model returns more than N, truncate to the
**highest-confidence N** and **state in the response that it did so**. Never silently drop rules
without saying so.

**VERIFY** — upload a 15-page PLAN document, select 10, run extraction. **Expect at most 10 rules**,
and a stated count.

---

## Item 4.4 — Extraction progress ✅ fix known

**Symptom:** the workflow stages are not visible; the operator cannot tell what is happening.

**Target:** explicit stages with **numbers**, not a spinner:

```
Parsing        ✓  18 pages
Chunking       ✓  42 chunks (3 table chunks)
Retrieval      ✓  12 candidate passages
Extraction     ●  6 of 10 rules
Compilation    ○
```

Per mockup, document rows carry: *"18 pages · 42 chunks · 3 table chunks · 12 rules"*.

**VERIFY** — run an extraction and confirm each stage renders with counts and advances visibly.

---

## Item 4.5 — Approve flow ✅ fix known, one extension flagged

**Symptom:** selecting rules produces no Approve control. A link opens a popup too small to read.

**The mockup specifies** (`MOCKUP_RULE_LIST_MANAGEMENT.html`) a **full rule list mounted on Documents
& Rules** — not a popup:

- Header counts: *"7 extracted · 3 compiled · 1 need a value · 2 need data we don't have"*
- Draft pool **grouped by status** — Compiled / Draft / Need a Value / Need Data — each group header
  carrying a count and a **select-all checkbox**; every row a checkbox
- Group heading style: **"Compiled — Awaiting Approval"**
- Filters: status, provenance, scope, severity — options derived from the loaded rules, `""` = All
- **Delete Selected (n)** → confirm modal listing exactly what will go (code, name, status)
- Published group is also selectable, so a mixed selection is possible → **Delete disables** with:
  *"The selection includes approved rules — approved rules can never be deleted, only superseded or
  deactivated, so Delete is disabled."*
- Approved rows carry **Deactivate / Reactivate** → shared ReasonModal, **reason REQUIRED** (the API
  400s without one). Inactive renders as an amber chip with the recorded who/when/why beneath the row.
- NEEDS_DATA rules **name the missing field**: *"needs `team_agreement.split_pct` effective date
  history, which the schema does not carry."*
- Chips: StatusChip, ProvenanceChip (glossary tooltip), AppliesToChip (ALL renders nothing),
  SeverityChip

**Per-rule review**, per `MOCKUP_RULE_AUTHORING.html`: expanding a row shows statement, worked
example, plan JSON, plain-English explanation, and **"Approve this plan"**.

**⚠️ Extension beyond the mockup — flagged deliberately.** The mockup has **no bulk approve control**.
It specifies per-rule *"Approve this plan"* and bulk *Delete Selected*. **The operator requires bulk
approve** — approving 12 extracted rules one at a time is unusable.

**Build:** a persistent action bar with **`Approve Selected (n)`** and **`Approve All Compiled`**,
alongside `Delete Selected (n)`. **Per-rule review must remain reachable** so an operator can inspect
before approving. Note in the completion report that this extends the mockup.

**VERIFY** — extract rules, select several, approve in bulk; approve one individually after review;
confirm approved rules cannot be deleted and the disabled-Delete note appears.

---

## Item 4.6 — Generate Query ⚠️ diagnose then fix

**Symptom:** Generate Query does nothing — on the Rules page **and** in Write a Rule. The operator also
expected a plan to be generated automatically after extraction; it is not.

**Target**, per mockup:

> `POST /api/rules/manual {generate_query: true}` runs the Rule Compiler; the compiled plan (JSON +
> plain-English explanation) is shown for review **with an Approve action BEFORE any publish**.
>
> `generate_query: false` → `natural_language_only: true`, **no plan**, labelled exactly
> **"Guidance only, not computed"**. Never evaluated; injected into the Insights Miner's opening as
> labelled guidance; never produces an impact figure.

**Diagnose:** does the button fire a request? Does the request reach the endpoint? Does the endpoint
call the compiler? Does the compiler return a plan or an error? Is the response rendered?
**Report where the chain breaks.** Check both surfaces — they may break in different places.

**Also determine:** should extraction auto-compile? The mockup shows extracted rules in a **Compiled**
group awaiting approval, which implies compilation happens during extraction. Confirm against the
extraction pipeline and state what you find.

**VERIFY** — write a rule in plain English with `generate_query: true`, confirm a plan and explanation
appear with an Approve action. Then with `generate_query: false`, confirm no plan and the exact label
*"Guidance only, not computed"*.

---

## Item 4.7 — Preview ⚠️ diagnose then fix

**Symptom:** Preview does not work, and does not appear where it should.

**Target:** Preview renders in the **right side of the main component** on that page — not a modal,
not a popup. It shows what the rule matches against real data: match count, sample rows, and the
figure the rule would produce.

**Diagnose:** does Preview call an endpoint? Does that endpoint evaluate the plan? **Preview must
evaluate through the same path as production rule evaluation** — `rules_evaluate_plan` over
`rule_evaluation_rows`. If Preview uses a separate path, that is a defect in itself: preview and
production must agree, or the operator approves a rule that behaves differently once published.

**Report which path Preview currently uses.**

**VERIFY** — preview a rule with a threshold that matches, confirm rows and a count. Change the
threshold so it matches nothing, confirm an honest empty result that distinguishes *"no rows matched
the filter"* from *"rows matched but none exceeded the threshold"*.

---

## Item 4.8 — Match the mockups

With behaviour fixed, compare each screen against its mockup and close the visual gaps: layout,
grouping, chips, counts, empty states, button placement.

**Where current UI and mockup disagree, the mockup wins** — unless the current behaviour is a
deliberate demo fix, in which case **state it and ask** rather than reverting it.

---

## Acceptance for Phase 4

- [ ] Per-row category dropdown removed; upload-time category retained; PLAN/FAQ gate intact
- [ ] Extract offer on upload; never auto-runs
- [ ] Extraction count honoured — select 10, get at most 10, count stated
- [ ] Staged progress with numbers
- [ ] Approve flow in a full-width list; bulk approve **and** per-rule review both work
- [ ] Approved rules cannot be deleted; disabled-Delete note appears on mixed selection
- [ ] Deactivate/Reactivate requires a reason
- [ ] NEEDS_DATA rules name the missing field
- [ ] Generate Query works on both surfaces; `generate_query: false` produces the exact guidance label
- [ ] Preview renders right-side, evaluates through the production path, distinguishes the two empty cases
- [ ] Screens match their mockups
- [ ] Backend and frontend running

---

## Do not, in this phase

- Implement a fix for an undiagnosed cause — stop and report instead
- Remove the upload-time category selection (only the per-row dropdown goes)
- Let extraction auto-run without an operator click
- Enforce the extraction cap only in the prompt — cap it in code
- Give Preview a different evaluation path from production
- Revert a deliberate demo fix without asking
