# Phase 5 — Opportunities and Coaching

**Read `00_MASTER_SPEC.md` first.** Phase 4 must be complete and reviewed.

**Both items are diagnose-then-fix.** Read master spec §5. Partial evidence exists for Opportunities;
almost none for Coaching. **If you cannot determine a cause, stop and report.**

**Run this phase only after Phases 1–3.** Some of what looks broken here may already be fixed by the
catalog reconciliation and the rules path. Diagnose the *remaining* problem, not a symptom that has
already been resolved.

---

## Item 5.1 — Opportunities section ⚠️ diagnose then fix

**Symptom:** the Opportunities section shows no data.

### What is already known

**The queries exist and are wired.** All six are in the deployed 46-entry catalog **and** in the 60
installed queries — this is **not** a catalog gap:

| Query | Returns |
|---|---|
| `advisor_opportunities` | advisor_sid, stage_group, forecast_amount, actual_assets, opportunity_count, stalled_count, data_source |
| `advisor_opportunity_detail` | opportunity_id, eci_id, advisor_sid, advisor_valid, stage_name, stage_group, amount, actual_assets, days_to_close, is_stalled, ai_read, … |
| `advisor_pipeline` | advisor_sid, stage_group, opportunity_count, forecast_amount, actual_assets, stalled_count, invalid_advisor_count |
| `pipeline_by_stage` | stage_name, stage_group, opportunity_count, forecast_amount, actual_assets, stalled_count |
| `stalled_opportunities` | opportunity_id, eci_id, advisor_sid, stage_name, amount, days_past_due, … |
| `household_opportunities` | opportunity_id, eci_id, advisor_sid, stage_name, amount, … |

**The data is partly loaded:**

| | |
|---|---|
| `opportunity` vertices | **296,395** ✓ |
| `opportunity_by_advisor` edges | **296,395** ✓ advisor link intact |
| `opportunity_for_household` edges | **0** ✗ file is 15 bytes, header only |

**The zero-edge link is a known, deferred defect:** every CRM opportunity row has an empty `eci_id`,
so the household link never forms and ~11,000 opportunities collapse on a duplicate derived key.
**Do not attempt to fix the `eci_id` extraction in this phase** — it is a data-pipeline issue outside
this workstream. Record its impact accurately.

### Therefore, expect a split

- **Advisor-scoped queries should return data** — the advisor edge is intact.
- **`household_opportunities` cannot return anything** — it depends on the 0-edge link.

Since *nothing* is showing, either the advisor-scoped path is also broken, or the whole section is
gated on the household join.

### Diagnose

Run each of the six directly and record row counts and sample rows:

```bat
uv run python -c "from app.graph.queries.catalog import run_catalog_query as q; [print(n, q(n,p)['row_count']) for n,p in [('advisor_pipeline',{'advisor':'all'}),('pipeline_by_stage',{}),('advisor_opportunities',{'advisor':'all'}),('stalled_opportunities',{'advisor':'all'})]]"
```

Then answer:

1. Which of the six return rows, and which return zero?
2. Does the UI section gate on a query that returns zero — meaning one empty query blanks the whole
   section?
3. Does the advisor page call the advisor-scoped queries, or does it route through the household join?
4. Is `advisor_valid` / `invalid_advisor_count` filtering out rows? The schema carries
   `advisor_sid_raw` and `advisor_valid` — if most rows are flagged invalid, that is a finding worth
   quantifying.

### Fix

- **If the section is gated on `household_opportunities`**, degrade honestly: render advisor-scoped
  opportunities and state plainly that household grouping is unavailable because the household link
  carries no edges. **Do not hide the section, and do not silently show an empty table.**
- **If the advisor-scoped path is broken**, fix it — likely a parameter mismatch, a column contract
  gap, or a UI mapping error.
- **If the cause is elsewhere**, report it.

**VERIFY** — the Opportunities section on the Advisor AI Insights page shows pipeline data with
counts and forecast amounts, and states honestly what is unavailable.

---

## Item 5.2 — Coaching section ⚠️ diagnose then fix

**Symptom:** the Coaching section on the Advisor AI Insights page does not populate.

### What is known — very little

This section has never been diagnosed. All that is established:

- `app/agents/coach.py` exists
- `app/knowledge/` exists with `chroma_client.py`, `chunker.py`, `embedding.py`, `rag_service.py`,
  `graph_writer.py`, `knowledge_service.py`, `vector_store.py`, `parsing/`
- `coaching.db` held **1 row** before the Phase 3 reset
- The knowledge catalog held **2 documents, 52 chunks**

**That is the entire evidence base.** Do not assume a cause.

### The intended design

Documents in the non-extraction categories — **GUIDANCE, PLAYBOOK, TRAINING** — feed Coaching and chat.
Only PLAN and FAQ feed the Rule Extractor. This is what makes the other categories worth having.

Confirm `coach.py` actually sources from those categories. If it sources from somewhere else, or from
nothing, that is the finding.

### Diagnose

1. Trace `GET` for the coaching section from the router through to `coach.py`.
2. Does it query Chroma? Which collection? Does that collection have content?
3. Does it filter by document category? Which categories does it accept?
4. Does it call the LLM? Does the call succeed?
5. Does it require insight-run context that no longer exists after the reset?
6. Is it feature-flagged off? Check `app/flags/registry.py` — `coaching` appears there.

**Check the flag first — it is the cheapest possible explanation:**

```bat
uv run python -c "import sqlite3; c=sqlite3.connect('data/runtime/feature_flags.db'); [print(r) for r in c.execute('select * from flag')]"
```

### Fix

Fix what you find. **If the cause is "no coaching documents have been uploaded", that is not a bug** —
say so, upload a GUIDANCE document, and re-test. The section should render an honest empty state
naming what it needs, not a blank panel.

**VERIFY** — upload a GUIDANCE document, generate an advisor insight, confirm the Coaching section
renders content sourced from that document, with the document cited.

---

## Item 5.3 — Citations across both sections

Per master spec and `MOCKUP_ROUND_A_DASHBOARD.html`, every finding traces to its source. Confirm:

- Coaching content cites the **document** it came from
- Opportunity findings cite the **query** and, where a rule is involved, the **rule**

The dashboard mockup's pattern: *"Rule: Sharing a Client Fee Discount · PCA · p. 4 · Discount…"*

**No number without a source.**

---

## Acceptance for Phase 5

- [ ] Each of the six opportunity queries exercised, row counts recorded
- [ ] Opportunities section populated with advisor-scoped data
- [ ] Household-level unavailability stated honestly, not hidden
- [ ] Coaching root cause identified and stated
- [ ] Coaching populated from GUIDANCE / PLAYBOOK / TRAINING documents
- [ ] Both sections cite their sources
- [ ] Honest empty states where data genuinely does not exist
- [ ] Backend and frontend running

---

## Do not, in this phase

- Attempt to fix the `eci_id` / household-edge data defect — record its impact only
- Hide a section because it is empty — render an honest empty state naming what is missing
- Implement a fix for an undiagnosed cause
- Assume Coaching is broken — confirm it is not simply un-fed or flagged off
