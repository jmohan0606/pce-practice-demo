# Starter Prompts

Put all six spec files in `docs/specs/` in the repo. Then paste the relevant prompt into Copilot.

**One phase per session.** Do not run two phases in one session — context fidelity drops and the
invariants in the master spec are what get lost first.

---

## Phase 1

> Read `docs/specs/00_MASTER_SPEC.md` in full, then `docs/specs/01_PHASE_1_LOCAL_STORE_GUARD.md`.
> Execute Phase 1 exactly as written.
>
> Follow the verify-before-change protocol in master spec §4 for every item: CHECK, COMPARE, then
> either record "already correct" or apply the fix, then VERIFY. Never change a file you have not
> first checked.
>
> Write your completion report to `docs/analysis/PHASE_1_COMPLETE.md` in the exact format in master
> spec §8. Paste exact command output — never paraphrase it.
>
> When you finish, leave the backend running on port 8002 and the frontend on its dev port, and
> confirm both respond. Expect endpoints that read local CSVs to start raising after this change —
> that is correct. Do not suppress those errors.
>
> If anything cannot be verified, say so plainly rather than inferring. Do not proceed to Phase 2.

---

## Phase 2

> Read `docs/specs/00_MASTER_SPEC.md` in full, then `docs/specs/02_PHASE_2_CATALOG_AND_RULES.md`.
> Phase 1 is complete and reviewed. Execute Phase 2 exactly as written.
>
> Three things matter most in this phase. **One:** `rules_evaluate_plan` is the Python plan
> interpreter — never create a GSQL query for it (master spec invariant 5). **Two:** before
> overwriting any deployed file with a reference copy, diff it and preserve deployed-only content —
> this environment contains demo fixes that exist nowhere else. **Three:** a rule query failure must
> raise, never become a silent zero.
>
> Follow the verify-before-change protocol for every item. Write your completion report to
> `docs/analysis/PHASE_2_COMPLETE.md` in the master spec §8 format.
>
> In §5 of the report, confirm April firm-basis revenue is still $397,389,374.54 and state the figure
> you measured.
>
> Leave backend and frontend running. Do not proceed to Phase 3.

---

## Phase 3

> Read `docs/specs/00_MASTER_SPEC.md` in full, then `docs/specs/03_PHASE_3_DELETE_AND_RESET.md`.
> Phase 2 is complete and reviewed. Execute Phase 3 exactly as written.
>
> Archive before you delete anything — `data\_archive_pre_reset\`. Do not touch `data\real`. Do not
> delete approved or published rules.
>
> If startup raises during V0 seeding after the reset, stop and report the exact error — do not work
> around it. It means a seed plan cannot validate against real data, which is a Phase 2 gap.
>
> Write your completion report to `docs/analysis/PHASE_3_COMPLETE.md` in the master spec §8 format.
> Item 3.6 is the real acceptance test for Phases 1–3 together — report it fully.
>
> Leave backend and frontend running. Do not proceed to Phase 4.

---

## Phase 4

> Read `docs/specs/00_MASTER_SPEC.md` in full, then
> `docs/specs/04_PHASE_4_DOCUMENTS_AND_RULES_UI.md`. Phase 3 is complete and reviewed.
>
> Open `docs/ui/MOCKUP_RULE_LIST_MANAGEMENT.html` and `docs/ui/MOCKUP_RULE_AUTHORING.html` before you
> start. They are the spec for this page — they state API shapes and behaviour, not just layout.
>
> Items 4.3, 4.6 and 4.7 state a goal and an acceptance test but **not** a fix, because nobody has
> diagnosed them. For those: diagnose first, report what you find, then fix. **If you cannot determine
> the cause, stop and report — do not implement a plausible-looking fix for an undiagnosed problem**
> (master spec §5). A report saying "four fixed, one undiagnosed with evidence attached" is a success.
>
> Write your completion report to `docs/analysis/PHASE_4_COMPLETE.md` in the master spec §8 format.
> For each diagnosed item, state the cause you found.
>
> Leave backend and frontend running. Do not proceed to Phase 5.

---

## Phase 5

> Read `docs/specs/00_MASTER_SPEC.md` in full, then
> `docs/specs/05_PHASE_5_OPPORTUNITIES_AND_COACHING.md`. Phase 4 is complete and reviewed.
>
> Both items are diagnose-then-fix. Partial evidence exists for Opportunities; almost none for
> Coaching — do not assume a cause for Coaching, and check the feature flag first.
>
> Do not attempt to fix the `eci_id` / household-edge data defect. Record its impact only.
>
> Do not hide a section because it is empty. Render an honest empty state naming what is missing.
>
> **If you cannot determine a cause, stop and report** (master spec §5).
>
> Write your completion report to `docs/analysis/PHASE_5_COMPLETE.md` in the master spec §8 format.
>
> Leave backend and frontend running.

---

## If a phase goes wrong mid-session

> Stop. Do not attempt a second, different fix. Write what you have so far to the completion report —
> what you checked, what you changed, what failed, and the exact output. Leave the application in a
> runnable state if you can, and say plainly if you cannot.

---

## What to look for when reviewing each completion report

Same discipline that has worked so far:

1. **Read §4 "What I could not do" first.** The gaps are where the findings are.
2. **Check that quoted output actually shows what the conclusion claims.**
3. **A zero is a finding** — a count of 0, an empty result, an unchanged file.
4. **Check the file list in §3 against what the phase asked for.** Extra files are a question; missing
   files are a question.
5. **Never accept "all checks passed" on its word** — the check commands are in the spec, re-run the
   decisive ones.
6. **Numbers must reconcile.** April firm-basis $397,389,374.54, every time revenue is touched.
