# Phase 1 — Local Store Guard

**Read `00_MASTER_SPEC.md` first.**

**Goal:** the local CSV store can never serve a read in real mode. This stops the memory crash and
ends mock data in real mode in one change.

**Why this is first:** it is one guard, it cannot change any figure, and it converts every remaining
local read into a loud, self-identifying error — which is the worklist for Phase 2.

---

## Evidence behind this phase

Measured directly. A single call to `GET /api/exceptions/firm` grew the uvicorn working set from
154.65 MB to **6,718.76 MB in 59.6 seconds** and had not finished when the 60-second timeout cut it.
The path is `app/api/routers/exceptions_api.py:32` → `compute_firm_exceptions` → `_cohort_sids` /
`_advisor_accounts` → local `all_vertices`.

`data\real` contains the **real extracts**: 18 vertex CSVs totalling 5,379,893,298 bytes
(`revenue_transaction.csv` alone is 3.43 GB), plus 31 edge files. `FoundationGraphStore.load()` runs
`list(csv.DictReader(f))` over every file in the manifest and builds a Python dict per row, plus
`out_index` and `in_index` entries per edge row.

**6.7 GB is a floor, not a peak.** The request was still growing when it was cut.

---

## Item 1.1 — Add the real-mode guard

**CHECK**

```bat
findstr /N /C:"def get_foundation_store" app\graph\foundation_store.py
findstr /C:"graph_client_mode" app\graph\foundation_store.py
```

**Target state:** `get_foundation_store()` raises when the mode is not `mock` or `local`.

**If the second command returns nothing, the guard is absent — apply the fix.**

**FIX** — in `app/graph/foundation_store.py`, at the top of `get_foundation_store()`, before the
store is constructed or loaded:

```python
def get_foundation_store() -> FoundationGraphStore:
    from app.config.settings import get_settings
    mode = str(get_settings().graph_client_mode or "").lower()
    if mode not in {"mock", "local"}:
        raise RuntimeError(
            f"local CSV store requested in {mode!r} mode — this is the mock data path "
            f"and must never serve real-mode reads. Route this read through "
            f"run_catalog_query / lookups instead. "
            f"(FoundationGraphStore loads multi-gigabyte CSVs into Python; it is the mock tier only.)"
        )
    global _store
    ...
```

Keep the existing body below it unchanged.

**VERIFY**

```bat
uv run python -c "from app.graph.foundation_store import get_foundation_store; get_foundation_store()"
```

**Expect:** `RuntimeError` naming the mode and telling the caller to use `run_catalog_query`.
**If it returns a store object, the guard is not effective — stop and report.**

---

## Item 1.2 — Confirm mock mode still works

The guard must not break mock mode.

**CHECK / VERIFY**

```bat
set GRAPH_CLIENT_MODE=mock
uv run python -c "from app.graph.foundation_store import get_foundation_store; s=get_foundation_store(); print('mock mode OK, vertex types:', len(s.vertices))"
set GRAPH_CLIENT_MODE=real
```

**Expect:** a store, no exception. If mock mode raises, the guard condition is wrong — fix and
re-verify.

---

## Item 1.3 — Inventory what now raises

The guard makes every remaining local read announce itself. Capture that list — it is Phase 2's scope.

**CHECK**

```bat
for %D in (rules insights agents api graph chat export knowledge) do @echo === app\%D === & @findstr /s /n /c:"get_foundation_store(" /c:"all_vertices" app\%D\*.py
```

**Record the complete output in the completion report.** Do not fix these in this phase — Phase 2
converts them.

For each call site, note in the report whether it is:
- **production read** — must be converted in Phase 2
- **inside `app/graph/`** — part of the mock tier itself, legitimate
- **test or script** — legitimate

---

## Item 1.4 — Measure the effect

Re-run the exact measurement that found the bug. **The measurement that found it is what proves the
fix.**

**CHECK** — start the backend, then:

```bat
powershell.exe -NoProfile -Command "$url='http://127.0.0.1:8002/api/exceptions/firm?month=202605'; $sw=[Diagnostics.Stopwatch]::StartNew(); $peak=0.0; $job=Start-Job -ScriptBlock { param($u) try { $r=Invoke-WebRequest -UseBasicParsing -Uri $u -TimeoutSec 60; 'HTTP_STATUS='+[string]$r.StatusCode } catch { 'REQUEST_ERROR='+$_.Exception.Message } } -ArgumentList $url; while ($job.State -eq 'Running' -and $sw.Elapsed.TotalSeconds -lt 60) { $p=Get-Process -Name python -ErrorAction SilentlyContinue | Sort-Object WorkingSet64 -Descending | Select-Object -First 1; if ($p) { $mb=$p.WorkingSet64/1MB; if ($mb -gt $peak) {$peak=$mb}; Write-Output ('SAMPLE elapsed_s={0:F1} uvicorn_working_set_mb={1:F2}' -f $sw.Elapsed.TotalSeconds,$mb) }; Start-Sleep -Milliseconds 1000 }; Receive-Job $job; Remove-Job $job -Force; Write-Output ('PEAK_UVICORN_WORKING_SET_MB={0:F2}' -f $peak)"
```

**Expect one of two outcomes, both acceptable:**

- **A fast error** naming the local store — the endpoint now refuses instead of loading CSVs. This is
  the correct Phase 1 outcome. Working set stays flat (low hundreds of MB).
- **A completed response** with flat memory — only if the path already routes through TigerGraph.

**Not acceptable:** working set climbing into the gigabytes. If that happens, a local read is
bypassing the guard — find it and report.

**Include the full sample curve and `PEAK_UVICORN_WORKING_SET_MB` in the completion report**, next to
the pre-fix figure of 6,718.76 MB.

---

## Item 1.5 — Restore the store-read guard script

**CHECK**

```bat
if exist scripts\check_store_reads.py (echo PRESENT) else (echo ABSENT)
```

**If ABSENT**, copy `scripts/check_store_reads.py` from the reference tree at
`reference\codespace_latest\scripts\check_store_reads.py`. Copy **only this file**.

**VERIFY**

```bat
uv run python scripts\check_store_reads.py
```

Record the output. It will likely FAIL — that is expected and correct at this stage, and its output is
the same worklist as Item 1.3. Do not change the baseline in the script to make it pass.

---

## Acceptance for Phase 1

- [ ] `get_foundation_store()` raises in real mode, with a message naming the mode and the remedy
- [ ] Mock mode still returns a store
- [ ] `GET /api/exceptions/firm` no longer grows the process into the gigabytes
- [ ] Complete list of remaining local read sites recorded in the report
- [ ] No client-facing figure changed — this phase cannot change one, confirm it did not
- [ ] Backend and frontend both running and responding

---

## Do not, in this phase

- Convert any call site to `run_catalog_query` — that is Phase 2
- Copy any file except `scripts/check_store_reads.py`
- Suppress or catch the new RuntimeError anywhere to keep endpoints quiet
- Change the baseline in `check_store_reads.py`
- Delete or move `data\real`
