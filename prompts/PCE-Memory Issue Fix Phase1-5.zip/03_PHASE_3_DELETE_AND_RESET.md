# Phase 3 — Delete Controls and Clean Reset

**Read `00_MASTER_SPEC.md` first.** Phase 2 must be complete and reviewed.

**Goal:** working delete controls with correct cascade, then a clean slate — 7 V0 seed rules, one
version, zero documents, zero insights.

---

## Why the order is forced

`ensure_v0_seed()` no-ops whenever **any** rule-set version exists. `RSV_v4` exists, so the seed has
not run in a long time.

Clear the rule store and the seed **will** run at next startup — and it calls `validate_plan`, which
**executes plans against data**. If the rules path is not working, that raises at startup and the app
will not come up.

**This is why Phase 2 comes first.** Do not attempt the reset unless Phase 2's acceptance is met.

---

## Current state to be cleared

| Store | Contents |
|---|---|
| `data\runtime\rule_store.db` | 163 rules, 5 rule-set versions, RSV_v4 published |
| `data\runtime\insight_runs.db` | 55 insight runs, 109 findings, 673 log rows |
| `data\runtime\chat.db` | 16 chat messages, 2 conversations |
| `data\runtime\coaching.db` | 1 coaching row |
| Chroma / knowledge | 2 catalogued documents, 52 chunks |

**The 163 rules are the extraction-count bug accumulating** — the count dropdown is ignored, so a
15-page document produces 100+ rules. Phase 4 fixes the cause; this phase clears the residue.

---

## Item 3.1 — Document delete with cascade

**CHECK**

```bat
findstr /s /n /c:"delete" app\api\routers\documents.py
```

**Target:** `DELETE /api/documents/{id}` exists and cascades correctly.

**FIX** — deleting a document must remove:

1. The stored file
2. **Its Chroma collection / embeddings** — otherwise it keeps surfacing in RAG retrieval and chat
3. Extracted rules from that document that are **not yet approved or published**
4. Extraction job records for that document
5. The document's knowledge-catalog rows

**It must NOT remove approved or published rules.** Those have produced numbers a client may have
seen. If a document has published rules, the response states that plainly — which rules survive and
why — rather than orphaning them silently. Per master invariant 7.

**VERIFY** — upload a throwaway document, extract, delete it, then confirm: file gone, Chroma
collection gone, unapproved rules gone, published rules (if any) retained **with a message saying so**.

---

## Item 3.2 — Insight delete, per version

**CHECK**

```bat
findstr /s /n /c:"delete" app\api\routers\insights.py
```

**Target:** an insight run can be deleted **by version**, everywhere insights appear — firm level,
dashboard sidebar, Advisor AI Insights page.

**FIX** — `DELETE /api/insights/{run_id}` removing that run and its findings, evidence rows, and log
rows. **Only the selected version.** Add the control to each surface that displays insights.

**VERIFY** — generate an insight, delete it, confirm it is gone from the UI and from
`insight_runs.db`, and that other runs are untouched.

---

## Item 3.3 — Chase the empty-SID row

**Evidence:** a post-restart Exceptions advisor list returned a row with **an empty `advisor_sid`, an
empty `advisor_name`, and `exception_count: 2`**.

```json
{"advisor_sid":"","advisor_name":"","exception_count":2}
```

This is a persisted finding with no advisor reference — a wrong number on screen.

**CHECK**

```bat
uv run python -c "import sqlite3; c=sqlite3.connect('data/runtime/insight_runs.db'); [print(r) for r in c.execute(\"select * from insight_finding where advisor_sid is null or trim(advisor_sid)='' limit 20\")]"
```

**Diagnose:** does the empty SID come from a persisted row, or from a join that fails to match? If the
cause is fixed by Phase 2's conversion, say so. If it is bad persisted data, the reset clears it — but
**add a guard so a finding cannot be written without an advisor reference**, or the same rows come
back.

---

## Item 3.4 — Archive, then reset

**Archive first. Do not delete.** These files are the only record of what the application produced
before the fixes.

```bat
mkdir data\_archive_pre_reset
copy data\runtime\rule_store.db    data\_archive_pre_reset\
copy data\runtime\insight_runs.db  data\_archive_pre_reset\
copy data\runtime\chat.db          data\_archive_pre_reset\
copy data\runtime\coaching.db      data\_archive_pre_reset\
```

Also archive uploaded documents and the Chroma store directory. Record every path archived.

**Then reset**, with the app stopped:

- Remove the rule-set versions and rules from `rule_store.db` (or move the file aside so it is
  recreated)
- Clear `insight_runs.db` — runs, findings, evidence, log rows
- Clear `chat.db` and `coaching.db`
- Remove uploaded documents and their Chroma collections
- Clear the knowledge document/chunk catalog rows

**Do not touch `data\real`.** Phase 1's guard means it is never read in real mode, and it is the
staging set for the TigerGraph load.

**VERIFY** — start the backend and confirm the seed ran:

```bat
uv run python -c "from app.rules.store import get_rule_store; s=get_rule_store(); v=s.latest_version('PUBLISHED'); print(v); [print(' ',r['rule_code'],r.get('status'),r.get('active')) for r in s.version_rules(v['version_id'])]"
```

**Expect exactly:**

```
7 rules, 1 version
NEW_ACCOUNT, ACCOUNT_TRANSFERRED_IN, ACCOUNT_TRANSFERRED_OUT, NEW_BILLING,
LOST_ACCOUNT, RETAINED_ACCOUNT, HIGH_9R_MONTH
```

**If startup raises during seeding, stop and report the exact error.** It means a V0 plan cannot
validate against real data — a Phase 2 gap, not something to work around here.

---

## Item 3.5 — Confirm the clean state

```bat
uv run python -c "import sqlite3,glob; [ (print('==',p),[print('  ',t[0],sqlite3.connect(p).execute('select count(*) from \"'+t[0]+'\"').fetchone()[0]) for t in sqlite3.connect(p).execute(\"select name from sqlite_master where type='table'\").fetchall()]) for p in glob.glob('data/runtime/*.db') ]"
```

**Expect:** 7 rules, 1 rule_set_version, 0 insight runs, 0 findings, 0 chat messages, 0 documents.

Then confirm through the UI: Documents page empty, Rules page showing 7 seed rules, no insights on
dashboard / sidebar / advisor pages.

---

## Item 3.6 — Prove the app works from clean

With a clean store and real data, generate one practice-level insight for 202604 → 202605.

Record:
- Did it complete?
- Did rules evaluate — `evaluated=True` on all seven?
- Do lifecycle counts appear, **labelled with their rule**?
- Do citations link rule and document?
- April firm-basis still **$397,389,374.54**?

**This is the real acceptance test for Phases 1–3 together.** If it works from a clean slate against
real data, the foundation is sound and Phase 4 can proceed.

---

## Acceptance for Phase 3

- [ ] Document delete cascades to file, Chroma, unapproved rules, jobs, catalog rows
- [ ] Published rules survive document delete, and the response says so
- [ ] Insight delete works per version on every surface
- [ ] Empty-SID row diagnosed and guarded against recurrence
- [ ] Everything archived to `data\_archive_pre_reset\` before deletion
- [ ] Clean state: 7 rules, 1 version, 0 documents, 0 insights
- [ ] App starts cleanly; seed ran without error
- [ ] One insight generated end to end from clean, with rules evaluated and citations present
- [ ] **April firm-basis is still $397,389,374.54**
- [ ] Backend and frontend running

---

## Do not, in this phase

- Delete anything before archiving it
- Touch `data\real`
- Reset before Phase 2's acceptance is met
- Delete approved or published rules
- Work around a seeding failure — report it
