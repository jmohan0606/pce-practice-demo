# Comparison Bench — Build Spec

**Read `00_MASTER_SPEC.md` first.**

Build a new screen in the application that runs the same business question against TigerGraph
and against Aurora PostgreSQL, and records what each costs and how good each answer is.

---

## The eight questions

| # | Question | Expected result |
|---|---|---|
| Q1 | Credited revenue by advisor, one month | PostgreSQL wins |
| Q2 | New / lost / retained / transferred accounts between two months | PostgreSQL competitive |
| Q3 | Which of my households are also served by another advisor, and who | TigerGraph wins on cost |
| Q4 | Revenue by product group per household, rolled up the hierarchy | TigerGraph wins on cost |
| Q5 | Peer cohorts discovered by similarity, then ranked within cohort | PostgreSQL cannot express |
| Q6 | Which advisors are hubs of book movement in the transfer network | PostgreSQL cannot express |
| Q7 | Which accounts look structurally like ones that already transferred away | PostgreSQL cannot express |
| Q8 | Which product group is this household most likely to hold next | PostgreSQL cannot express |

**Q1 and Q2 are expected to favour PostgreSQL. Report that accurately.** A bench that only
shows wins is not believed. The argument is the shape of the curve, not a clean sweep.

---

## NEVER — read this twice

- **Never modify Aurora.** No DDL, no indexes, no comments, no tables. Read-only queries only.
- **Never modify the TigerGraph schema.** Run GDS algorithms in print mode with
  `result_attribute` empty.
- **Never pull data to disk or hold a large result in memory.** Both engines aggregate in the
  database. A query returning more than 50,000 rows to the application is a defect in that
  query — fix the query, do not accept the result.
- **Never generate SQL or GSQL with a model.** Every query is hand-written.
- **Never refactor, tidy, optimise or fix anything you were not asked to.** Find a bug, write
  one line about it in the checkpoint report, leave it alone.
- **Never retry a failing query with a longer timeout.** A timeout is a result. Record it.
- **Never truncate, sample or approximate to make something fit.**
- **Never edit an existing file** except the two one-line registrations named in Stage 4.

---

## ALWAYS

- Hand-write every query, both engines.
- Run long commands through `scripts/run_bounded.py`, 120-second default.
- Record three timings per query per engine. Report all three. Never an average.
- Stop at each checkpoint, leave the application working, write the report, wait.
- **Respect the time-box on each stage.** If it runs out, stop at the checkpoint with what you
  have. Partial is fine. Overrunning is not.

---

# Stage 1 — Connection and schema map · time-box 2 hours

**1.1** Add `psycopg[binary]`. New module `app/bench/pg_client.py` — connect using the RDS IAM
token command the operator supplies. Read-only, pooled, our own statement timeout.
Verify with `SELECT 1` and the server version.

**1.2** For these eleven entities only, find the Aurora table and the columns we use:

```
advisor · account · account_month · household · product · product_group
revenue_transaction · monthly_revenue · account_transfer · team_agreement · opportunity
```

Use `information_schema.columns` and `pg_class.reltuples`. Do not fetch rows.

**1.3** Write `app/bench/schema_map.json` — per table: Aurora table name, matching TigerGraph
vertex type, columns used with declared types, one-line description per column, and the join
columns to other tables.

**Flag every date or timestamp column declared as `text` or `varchar`**, and record the cast
each query will need.

**→ CHECKPOINT 1**

---

# Stage 2 — Q1 to Q4 · time-box 4 hours

Two new files per question:

- `app/bench/queries/q<N>_tg.py` — calls an installed GSQL query
- `app/bench/queries/q<N>_pg.py` — hand-written SQL

Both return the same result shape. Both aggregate in the database.

Paths for the traversal questions:

- **Q3** advisor → account_month → account → household → account → account_month → other advisor
- **Q4** advisor → accounts → transactions → product → product_group

**→ CHECKPOINT 2**

---

# Stage 3 — Q5 to Q8 · time-box 6 hours

**3.1 TigerGraph side.** Install the GDS algorithms needed, from TigerGraph's open library:

| Question | Algorithm family |
|---|---|
| Q5 | Similarity (Jaccard or cosine neighbourhood) |
| Q6 | Centrality over the account transfer edges |
| Q7 | Community detection over transfers, plus similarity on advisor and product profile |
| Q8 | Topological link prediction over household → product_group |

Save each source to `docs/tigergraph/queries/`, install, register in the catalog with column
contracts. **Print mode only** — no schema change.

**These are GSQL queries.** No machine learning model, no training, no inference runtime, no
new Python dependency beyond the PostgreSQL driver.

**3.2 PostgreSQL side — time-box 30 minutes per question.** Attempt each honestly. When the
30 minutes is up, stop and record:

- the approach tried
- where it broke down
- what would have to be hand-implemented to make it work

**That finding is the deliverable.** Do not spend longer trying to make it work.

**→ CHECKPOINT 3**

---

# Stage 4 — Harness and screen · time-box 4 hours

**4.1** `app/bench/runner.py` — per question per engine record: expressible yes/no, three
latencies, rows returned, peak memory, and the result.

**4.2** Agreement check: where both engines return a figure, compare them. A mismatch is a
finding to show, not hide.

**4.3** New router `app/api/routers/bench.py`, new page `/bench`, behind a feature flag named
`bench_screen`, default off.

**The UI specification is `docs/spec/bench_screen_mockup.html`.** Open it. The layout, element
structure and states are the specification; the figures in it are placeholders. Implement:

- Header with both engine connection indicators, Run all, Export
- Summary strip: questions, expressible on both, PostgreSQL cannot express, PostgreSQL faster, figures agree
- Per question: number, question in business language, the path or method beneath it, a tag
- Three panes per question: TigerGraph metrics, PostgreSQL metrics, and a verdict showing the
  multiple and which engine won
- **Three states for the PostgreSQL pane:** metrics, *not expressible* with the reason and the
  attempt note, or *pending* where the question is not yet built
- Agreement line where both return a figure
- Judge panel, shown only where Stage 5 has run, with five scored bars per engine
- Links to the GSQL, the SQL, the query plan, the result and the attempt notes

**A question not yet built renders as a dimmed pending row.** The screen must work with
whatever subset of questions exists.

**The only two existing files touched: one line to register the router, one line to register
the flag.**

**→ CHECKPOINT 4**

---

# Stage 5 — Answer quality · time-box 4 hours

**5.1** Run the existing conversational agent twice per question — once with TigerGraph as its
data source, once with PostgreSQL — and capture both answers.

**5.2** `app/bench/judge.py`. Present both answers to the judge model **unlabelled and in
random order**, with the data each received. Score 0–10 with one line of reason each on:
groundedness, hallucination, completeness, specificity, honest failure.

**5.3** Separately and deterministically: where both sides return a figure, the figures must
match. Report any mismatch regardless of the judge's score. The judge scores language;
arithmetic is checked by arithmetic.

**Blinding is not optional.** An unblinded judge result will not survive review.

**→ CHECKPOINT 5**

---

# Checkpoint report — fixed format, one screen

Write `docs/analysis/BENCH_CP<n>.md`. **Keep it under 25 lines.** It will be read as a
screenshot. Use exactly this shape:

```
BENCH CHECKPOINT <n> — <stage name>
STATUS: complete | partial | blocked
TIME USED: <hours> of <time-box>

BUILT
  <new file>                       <one line>
  <new file>                       <one line>
TOUCHED
  <existing file>                  <what one line changed>

RESULTS
  Q<n> TG   <ms> / <ms> / <ms>   rows <n>   mem <MB>
  Q<n> PG   <ms> / <ms> / <ms>   rows <n>   mem <MB>   [or: NOT EXPRESSIBLE — <reason>]
  AGREE: Q<n> yes | no <figures>

SURPRISES
  <one line each — including anywhere PostgreSQL won>

BLOCKED
  <one line each, or: none>

NEXT: Stage <n+1>
```

No prose outside this shape. If something needs explaining at length, put it in a separate
file and name it on the BLOCKED line.

---

## Success

Eight questions, sixteen implementations, real numbers on both sides, and four honest
"cannot be expressed in SQL" findings with the attempts shown.

If PostgreSQL wins Q1 and Q2 outright, that is the expected and desirable result.

**A note on language.** Q7 and Q8 are relationship prediction and propensity scoring. They are
not revenue forecasting and must never be described as such.
