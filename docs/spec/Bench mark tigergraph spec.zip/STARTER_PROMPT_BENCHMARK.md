# Starter Prompt — Comparison Bench

**Before you paste:** put `BENCHMARK_BUILD_SPEC.md` and `bench_screen_mockup.html` into
`docs/spec/`. Then replace the marked block below with your Aurora connection parameters.

---

> Read `docs/spec/00_MASTER_SPEC.md` for context, then `docs/spec/BENCHMARK_BUILD_SPEC.md` in
> full. Build it, stage by stage.
>
> ## Aurora connection
>
> ```
> [PASTE YOUR RDS TOKEN COMMAND AND CONNECTION PARAMETERS HERE]
> ```
>
> **Do not hardcode anything from that block, and never paste a token into code.** RDS auth
> tokens expire in roughly 15 minutes, so a stored token is useless. Extract the host, port,
> database name, username and region from what I gave you, add them to the application's
> existing `.env` as new `BENCH_PG_*` variables, and have `app/bench/pg_client.py` mint a fresh
> token on every connection with
> `boto3.client("rds", region_name=...).generate_db_auth_token(...)`. `boto3` is already a
> dependency. Connect read-only, with SSL, and with our own statement timeout.
>
> If any parameter is missing from what I gave you, name it and stop. Do not guess it.
>
> ## Where files go
>
> **Specs to read:** `docs/spec/BENCHMARK_BUILD_SPEC.md` and `docs/spec/bench_screen_mockup.html`
>
> **New files you create:**
>
> ```
> app/bench/pg_client.py                 Aurora connection
> app/bench/schema_map.json              table, column and relationship map
> app/bench/runner.py                    the harness
> app/bench/judge.py                     the blind scorer
> app/bench/queries/q1_tg.py …           sixteen query files, q1–q8, _tg and _pg
> app/api/routers/bench.py               the API
> docs/tigergraph/queries/bench_*.gsql   new GSQL plus the GDS algorithms you install
> docs/analysis/BENCH_CP<n>.md           one per checkpoint
> ```
>
> **The frontend page:** find where the existing pages live and follow that convention exactly.
> Do not invent a new structure. Route it at `/bench`.
>
> **Existing files you may touch, one line each, and nothing else:**
>
> ```
> .env                              the BENCH_PG_* variables
> pyproject.toml                    psycopg[binary]
> the router registration file      register the bench router
> the feature flag registry         register bench_screen, default off
> ```
>
> If something seems to need a fifth file, stop and tell me rather than editing it.
>
> ## How to work
>
> **This is a build round. Do not research beyond what a stage asks for.** Every stage has a
> time-box. When it runs out, stop at the checkpoint with what you have — partial is fine,
> overrunning is not. A question not yet built renders as a dimmed pending row, so the screen
> works with whatever subset exists.
>
> **Eight things you must never do:**
>
> 1. Never modify Aurora — no DDL, no indexes, no comments. Read-only queries only.
> 2. Never modify the TigerGraph schema — run GDS algorithms in print mode, `result_attribute` empty.
> 3. Never pull data to disk or hold a large result in memory. A query returning over 50,000 rows to the application is a defect in that query. Fix the query.
> 4. Never generate SQL or GSQL with a model. Every query is hand-written, both engines.
> 5. Never refactor, tidy, optimise or fix anything you were not asked to. Find a bug, write one line about it, leave it alone.
> 6. Never retry a failing query with a longer timeout. A timeout is a result — record it.
> 7. Never truncate, sample or approximate to make something fit.
> 8. Never edit an existing file beyond the four named above.
>
> ## The work
>
> Eight questions, two hand-written implementations each. **Q1 and Q2 are expected to favour
> PostgreSQL — report that accurately.** A bench that only shows wins is not believed.
>
> For Q5 to Q8 you install algorithms from TigerGraph's open GDS library. **These are GSQL
> queries and nothing else** — no machine learning model, no training, no inference runtime, no
> new Python dependency beyond the PostgreSQL driver. On the PostgreSQL side for those four you
> have **30 minutes per question**. When it is up, record the approach, where it broke down, and
> what would have to be hand-implemented. That finding is the deliverable — do not keep trying.
>
> Three timings per query per engine, all three reported, never an average. Where both engines
> return a figure, compare them; a mismatch is a finding to show.
>
> **The UI is specified by `docs/spec/bench_screen_mockup.html`** — open it and implement that
> layout. The figures in it are placeholders; the structure and the three PostgreSQL pane states
> (metrics, not expressible, pending) are the specification.
>
> The judge in Stage 5 sees both answers **unlabelled and in random order**. Arithmetic is
> checked separately and deterministically; the judge scores language only.
>
> ## At each checkpoint
>
> Leave the application working. Write `docs/analysis/BENCH_CP<n>.md` in the exact fixed format
> in the spec — **under 25 lines, no prose outside that shape** — and stop. It will be read as a
> screenshot, so anything longer is lost. Then wait for me.
